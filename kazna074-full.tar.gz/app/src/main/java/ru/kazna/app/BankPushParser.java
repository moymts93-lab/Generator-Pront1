package ru.kazna.app;

/** Bank identity comes only from the posting Android package, never its displayed title. */
public final class BankPushParser {
 public static String sender(String pkg){
  if("ru.sberbankmobile".equals(pkg))return "900";
  if("com.idamob.tinkoff.android".equals(pkg))return "T-Bank";
  if("ru.alfabank.mobile.android".equals(pkg))return "AlfaBank";
  return null;
 }
 public static String payload(String title,String body){
  title=title==null?"":title.trim();body=body==null?"":body.trim();
  if(title.isEmpty()||body.startsWith(title))return body;
  if(body.isEmpty())return title;
  return title+"\n"+body;
 }
 public static Entry parse(String pkg,String title,String body,long time,String notificationKey){
  String from=sender(pkg);if(from==null)return null;
  String raw=payload(title,body);
  Entry e=BankParser.parse(from,raw,time,"bank_push");
  if(e!=null)e.key=BankParser.fingerprint("push|"+pkg+"|"+notificationKey+"|"+time);
  return e;
 }
}
