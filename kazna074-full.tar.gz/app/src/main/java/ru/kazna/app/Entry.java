package ru.kazna.app;
public class Entry {
 public long id,time,amount;
 /** Optional statement metadata. Long.MIN_VALUE means unknown. */
 public long balanceAfter=Long.MIN_VALUE,processedTime=0;
 public String key="",bank="",card="",merchant="",category="Другое",type="expense",raw="",source="sms",authCode="",counterparty="",bankCategory="";
 public boolean review;
 public boolean outgoing(){return type.equals("expense")||type.equals("transfer_out")||type.equals("own_out");}
 public boolean incoming(){return type.equals("income")||type.equals("transfer_in")||type.equals("own_in");}
 public boolean ownTransfer(){return type.equals("own")||type.equals("own_out")||type.equals("own_in");}
 public boolean counted(){return amount>0&&!type.equals("unknown");}
 public int direction(){
  if(type.equals("refund")||incoming())return 1;
  if(outgoing()||type.equals("cash"))return -1;
  return 0;
 }
}
