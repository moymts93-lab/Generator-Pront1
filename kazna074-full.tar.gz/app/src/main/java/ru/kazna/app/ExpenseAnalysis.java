package ru.kazna.app;
import java.util.*;

/** All breakdowns use the same gross outgoings as the chart; refunds remain separate. */
public final class ExpenseAnalysis {
 public final Ledger ledger;
 public final Map<String,Long> merchants=new LinkedHashMap<>(),banks=new LinkedHashMap<>();
 public final List<Entry> expenses=new ArrayList<>();
 public long largest;public int count;
 public ExpenseAnalysis(List<Entry> list){
  ledger=new Ledger(list);
  for(Entry e:list)if(e.counted()&&e.outgoing()&&!e.ownTransfer()){
   expenses.add(e);count++;largest=Math.max(largest,e.amount);
   String merchant=e.merchant.isEmpty()?"Без названия":e.merchant;
   merchants.put(merchant,merchants.getOrDefault(merchant,0L)+e.amount);
   banks.put(e.bank,banks.getOrDefault(e.bank,0L)+e.amount);
  }
 }
 public long average(){return count==0?0:ledger.expenses/count;}
 public static List<Map.Entry<String,Long>> sorted(Map<String,Long> values){
  List<Map.Entry<String,Long>> result=new ArrayList<>(values.entrySet());
  result.sort((a,b)->{int bySum=Long.compare(b.getValue(),a.getValue());return bySum!=0?bySum:a.getKey().compareTo(b.getKey());});return result;
 }
 public List<Entry> detail(String group,String value){List<Entry> out=new ArrayList<>();for(Entry e:expenses)if(group.equals("category")?e.category.equals(value):group.equals("merchant")?(e.merchant.isEmpty()?"Без названия":e.merchant).equals(value):group.equals("bank")?e.bank.equals(value):true)out.add(e);return out;}
}
