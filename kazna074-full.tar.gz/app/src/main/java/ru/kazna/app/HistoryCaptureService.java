package ru.kazna.app;
import android.accessibilityservice.AccessibilityService;import android.content.*;import android.graphics.Rect;import android.os.*;import android.view.*;import android.view.accessibility.*;import android.widget.*;import java.time.*;import java.util.*;
/** User-triggered, read-only prototype. No text inspection in the event callback. */
public class HistoryCaptureService extends AccessibilityService {
 public static volatile HistoryCaptureService instance;private static StatementParser.Result completed;
 final Handler handler=new Handler(Looper.getMainLooper());LinearLayout overlay;boolean running;long deadline;int pages;final Set<String> seen=new HashSet<>();final List<StatementParser.Row> rows=new ArrayList<>();int skipped,visited;
 static synchronized StatementParser.Result takeResult(){StatementParser.Result r=completed;completed=null;return r;}
 @Override protected void onServiceConnected(){instance=this;}
 @Override public void onAccessibilityEvent(AccessibilityEvent event){} // Permissions alone never start collection.
 @Override public void onInterrupt(){stop();}
 @Override public void onDestroy(){stop();if(instance==this)instance=null;super.onDestroy();}
 public void begin(){stop();completed=null;seen.clear();rows.clear();pages=0;skipped=0;running=true;deadline=SystemClock.elapsedRealtime()+180000;
  overlay=new LinearLayout(this);overlay.setOrientation(1);overlay.setPadding(12,8,12,8);overlay.setBackgroundColor(0xff183b31);TextView title=new TextView(this);title.setText("Казна · история Сбера · 3 минуты");title.setTextColor(-1);overlay.addView(title);
  Button capture=new Button(this);capture.setText("Считать видимый экран");capture.setOnClickListener(v->capture());overlay.addView(capture);
  LinearLayout actions=new LinearLayout(this);Button next=new Button(this);next.setText("Прокрутить");next.setOnClickListener(v->scroll());actions.addView(next,new LinearLayout.LayoutParams(0,-2,1));Button done=new Button(this);done.setText("Проверить");done.setOnClickListener(v->finishCapture());actions.addView(done,new LinearLayout.LayoutParams(0,-2,1));overlay.addView(actions);
  Button cancel=new Button(this);cancel.setText("Остановить без сохранения");cancel.setOnClickListener(v->{stop();rows.clear();});overlay.addView(cancel);
  WindowManager.LayoutParams lp=new WindowManager.LayoutParams((int)(getResources().getDisplayMetrics().density*285),-2,WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,android.graphics.PixelFormat.TRANSLUCENT);lp.gravity=Gravity.TOP|Gravity.RIGHT;lp.y=(int)(getResources().getDisplayMetrics().density*32);
  title.setText("Казна · потяни заголовок, чтобы сдвинуть");
  title.setOnTouchListener(new View.OnTouchListener(){float x,y;int startX,startY;public boolean onTouch(View v,android.view.MotionEvent event){if(event.getAction()==android.view.MotionEvent.ACTION_DOWN){x=event.getRawX();y=event.getRawY();startX=lp.x;startY=lp.y;return true;}if(event.getAction()==android.view.MotionEvent.ACTION_MOVE){lp.x=Math.max(0,Math.min(getResources().getDisplayMetrics().widthPixels-overlay.getWidth(),startX-(int)(event.getRawX()-x)));lp.y=Math.max(0,Math.min(getResources().getDisplayMetrics().heightPixels-overlay.getHeight(),startY+(int)(event.getRawY()-y)));getSystemService(WindowManager.class).updateViewLayout(overlay,lp);return true;}return true;}});
  getSystemService(WindowManager.class).addView(overlay,lp);handler.postDelayed(()->{if(running){stop();rows.clear();Toast.makeText(this,"Сбор остановлен по времени. Ничего не записано.",Toast.LENGTH_LONG).show();}},180000);
 }
 void stop(){running=false;handler.removeCallbacksAndMessages(null);if(overlay!=null){try{getSystemService(WindowManager.class).removeView(overlay);}catch(Exception ignored){}overlay=null;}}
 AccessibilityNodeInfo bankRoot(){if(!running||SystemClock.elapsedRealtime()>deadline){stop();return null;}AccessibilityNodeInfo root=getRootInActiveWindow();if(root==null||!"ru.sberbankmobile".contentEquals(root.getPackageName()==null?"":root.getPackageName())){if(root!=null)root.recycle();toast("Открой историю операций в Сбере");return null;}return root;}
 static final class Piece {String text;Rect bounds=new Rect();}
 void collect(AccessibilityNodeInfo node,List<Piece> parts,int depth){if(++visited>1200||depth>35||parts.size()>1000||node.isPassword()||node.isEditable()||!node.isVisibleToUser())return;
  CharSequence text=node.getText();if(node.getChildCount()==0){if(text==null)text=node.getContentDescription();if(text!=null&&text.length()>0&&text.length()<1000){Piece p=new Piece();p.text=text.toString();node.getBoundsInScreen(p.bounds);parts.add(p);}}
  for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo child=node.getChild(i);if(child!=null){collect(child,parts,depth+1);child.recycle();}}
 }
 List<String> text(AccessibilityNodeInfo root){visited=0;List<Piece> parts=new ArrayList<>();collect(root,parts,0);parts.sort((a,b)->{int y=Integer.compare(a.bounds.top,b.bounds.top);return y!=0?y:Integer.compare(a.bounds.left,b.bounds.left);});List<String> result=new ArrayList<>();int length=0;for(Piece p:parts){length+=p.text.length();if(length>30000)break;result.add(p.text);}return result;}
 void capture(){AccessibilityNodeInfo root=bankRoot();if(root==null)return;List<String> pieces;try{pieces=text(root);}finally{root.recycle();}String all=String.join("\n",pieces);
  if(!ScreenStatementParser.safeHistory(all)){toast("Нужен открытый экран истории с доступным текстом. Экраны входа не читаются.");return;}
  if(pages>=10){toast("Лимит 10 экранов. Нажми «Проверить».");return;}String hash=BankParser.fingerprint(all);if(!seen.add(hash)){toast("Этот экран уже прочитан");return;}
  StatementParser.Result parsed=ScreenStatementParser.parse(pieces,LocalDate.now(),"screen|"+hash);for(StatementParser.Row row:parsed.rows){row.entry.source="screen";row.selected=false;rows.add(row);}skipped+=parsed.skipped;pages++;toast("Экранов: "+pages+" · найдено строк: "+rows.size()+". Прокрути и считай следующий экран.");
 }
 boolean scrollNode(AccessibilityNodeInfo node,int depth){if(depth>25||node.isPassword()||node.isEditable())return false;if(node.isScrollable()&&node.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD))return true;for(int i=0;i<node.getChildCount();i++){AccessibilityNodeInfo child=node.getChild(i);if(child!=null){boolean done=scrollNode(child,depth+1);child.recycle();if(done)return true;}}return false;}
 void scroll(){AccessibilityNodeInfo root=bankRoot();if(root==null)return;try{if(!ScreenStatementParser.safeHistory(String.join("\n",text(root)))){toast("Прокрутка доступна только в истории");return;}if(!scrollNode(root,0))toast("Прокрути историю пальцем");}finally{root.recycle();}}
 void finishCapture(){StatementParser.Result r=new StatementParser.Result();r.rows.addAll(rows);r.skipped=skipped;r.note="Пробное чтение экрана Сбера. Проверь даты, суммы и описания. Пересекающиеся экраны могут содержать одинаковые покупки. По умолчанию строки не выбраны.";
  // Overlapping screens are possible duplicates, never silently removed.
  List<Entry> prior=new ArrayList<>();for(StatementParser.Row row:r.rows){if(StatementParser.possible(row.entry,prior)){row.warning="Похожа на строку с другого экрана — проверь";}prior.add(row.entry);}
  completed=r;rows.clear();stop();Intent intent=new Intent(this,ImportActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("screen",true);startActivity(intent);
 }
 void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
}
