package ru.kazna.app;
import android.app.*;import android.content.*;import android.graphics.Typeface;import android.graphics.drawable.GradientDrawable;import android.net.Uri;import android.os.*;import android.view.*;import android.widget.*;import android.text.InputType;import java.util.*;import java.util.concurrent.*;

/** Universal statement import: bank/period are detected from the file; verified statements sync automatically. */
public class ImportActivity extends Activity {
 final ExecutorService worker=Executors.newSingleThreadExecutor();StatementParser.Result result;String bank="",error="",syncMessage="";Uri uri;boolean loading,synced;int limit=50;int[] syncCounts=new int[3];LinearLayout body;ScrollView scroller;
 @Override public void onCreate(Bundle state){super.onCreate(state);if(state!=null){bank=state.getString("bank","");synced=state.getBoolean("synced",false);syncMessage=state.getString("syncMessage","");String u=state.getString("uri");if(u!=null)uri=Uri.parse(u);}
  Object retained=getLastNonConfigurationInstance();if(retained instanceof StatementParser.Result)result=(StatementParser.Result)retained;
  if(uri==null){uri=getIntent().getData();if(uri==null)uri=getIntent().getParcelableExtra(Intent.EXTRA_STREAM);}
  render();if(result!=null)return;if(uri!=null)read();else chooseFile();
 }
 @Override public Object onRetainNonConfigurationInstance(){return result;}
 @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putString("bank",bank);b.putBoolean("synced",synced);b.putString("syncMessage",syncMessage);if(uri!=null)b.putString("uri",uri.toString());}
 @Override protected void onDestroy(){worker.shutdown();super.onDestroy();}
 void ui(Runnable r){runOnUiThread(()->{if(!isDestroyed()&&!isFinishing())r.run();});}
 int dp(int n){return (int)(getResources().getDisplayMetrics().density*n+.5f);}
 TextView text(String s,int size,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(size);v.setTextColor(MainActivity.INK);if(bold)v.setTypeface(null,Typeface.BOLD);return v;}
 LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
 void add(LinearLayout p,View v){p.addView(v,new LinearLayout.LayoutParams(-1,-2));}
 void gap(LinearLayout p){p.addView(new View(this),new LinearLayout.LayoutParams(1,dp(10)));}
 TextView button(String s,Runnable run){TextView b=text(s,14,true);b.setGravity(Gravity.CENTER);b.setMinHeight(dp(48));b.setPadding(dp(12),dp(12),dp(12),dp(12));GradientDrawable g=new GradientDrawable();g.setColor(MainActivity.LIME);g.setCornerRadius(dp(12));b.setBackground(g);b.setOnClickListener(v->run.run());return b;}
 void chooseFile(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*");startActivityForResult(i,1);}
 @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==1&&res==RESULT_OK&&data!=null&&data.getData()!=null){uri=data.getData();bank="";result=null;synced=false;syncMessage="";read();}else if(result==null)finish();}
 void read(){loading=true;error="";render();worker.execute(()->{try{
   StatementFiles.Detected detected=StatementFiles.readAuto(this,uri);bank=detected.bank;StatementParser.Result r=detected.result;StatementParser.match(r,Store.get(this).all());
   if(r.verified){syncCounts=syncVerified(r);synced=true;}
   ui(()->{result=r;loading=false;render();});
  }catch(Exception ex){ui(()->{loading=false;error=ex.getMessage()==null?"Не удалось прочитать файл":ex.getMessage();render();});}});}
 int[] syncVerified(StatementParser.Result r){int[] counts=Store.get(this).importRows(r.rows);if(r.hasSummary){if(r.creditStatement)Store.get(this).syncCreditStatement(bank,r.accountCard,r.creditLimit,r.creditDebt);else Store.get(this).syncStatementAccount(bank,r.accountCard,r.closingBalance,"statement");}
  syncMessage=r.creditStatement?"Долг "+bank+": "+MainActivity.rub(r.creditDebt)+" · доступно "+MainActivity.rub(r.availableCredit):"Баланс "+bank+": "+MainActivity.rub(r.closingBalance);return counts;}
 void render(){
  final int scrollY=scroller==null?0:scroller.getScrollY();
  LinearLayout root=col();root.setBackgroundColor(MainActivity.BG);root.setPadding(dp(16),dp(12),dp(16),dp(12));root.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(dp(16)+in.getSystemWindowInsetLeft(),dp(12)+in.getSystemWindowInsetTop(),dp(16)+in.getSystemWindowInsetRight(),dp(12)+in.getSystemWindowInsetBottom());return in;});setContentView(root);root.requestApplyInsets();
  add(root,button("← Вернуться в Казну",this::finish));gap(root);add(root,text(bank.isEmpty()?"Импорт банковской выписки":"Выписка · "+bank,21,true));gap(root);
  ScrollView scroll=new ScrollView(this);scroller=scroll;scroll.post(()->scroll.scrollTo(0,scrollY));body=col();scroll.addView(body);root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
  if(loading){add(body,text("Читаю файл и определяю банк…",16,false));gap(body);add(body,text("Казна ищет банк, период, карты/счёт и контрольные суммы прямо в документе.",13,false));return;}
  if(!error.isEmpty()){add(body,text(error,16,false));gap(body);add(body,button("Выбрать другой файл",()->{uri=null;chooseFile();}));return;}if(result==null)return;
  add(body,text("Банк определён автоматически: "+bank,15,true));if(!result.periodFrom.isEmpty()||!result.periodTo.isEmpty()){gap(body);add(body,text("Период: "+result.periodFrom+" — "+result.periodTo,14,false));}gap(body);add(body,text(result.note,14,false));gap(body);add(body,text("Найдено операций: "+result.rows.size()+" · пропущено: "+result.skipped,14,true));gap(body);
  if(result.rows.isEmpty()){add(body,text("Не удалось выделить операции. Формат может быть многострочным или нестандартным. Ничего не записано.",16,false));return;}
  if(result.verified){renderVerified();return;}
  int chosen=0,possible=0,exact=0;long out=0,in=0,refunds=0;
  for(StatementParser.Row r:result.rows){if(r.possible)possible++;if(r.exact)exact++;if(r.selected&&!r.exact){chosen++;if(r.entry.outgoing())out+=r.entry.amount;else if(r.entry.incoming())in+=r.entry.amount;else if(r.entry.type.equals("refund"))refunds+=r.entry.amount;}}
  add(body,text("Проверка выписки не сошлась полностью — автоматическая синхронизация не выполнена.",14,true));gap(body);add(body,text("Уже импортированы: "+exact+" · возможные совпадения: "+possible,14,false));gap(body);add(body,text("Выбрано: "+chosen+"\nРасходы: "+MainActivity.rub(out)+" · поступления: "+MainActivity.rub(in)+"\nВозвраты: "+MainActivity.rub(refunds),16,true));gap(body);
  add(body,text("Спорные строки можно проверить вручную. Пока контрольные суммы не совпали, Казна не меняет баланс автоматически.",13,false));gap(body);
  add(body,button("Выбрать однозначные строки без совпадений",()->{for(StatementParser.Row r:result.rows)r.selected=!r.exact&&!r.possible&&r.warning.isEmpty()&&r.entry.counted();render();}));gap(body);
  for(int i=0;i<Math.min(limit,result.rows.size());i++){
   StatementParser.Row r=result.rows.get(i);LinearLayout box=col();box.setPadding(dp(12),dp(12),dp(12),dp(12));box.setBackgroundColor(MainActivity.WHITE);
   CheckBox selected=new CheckBox(this);selected.setText(MainActivity.formatDate(r.entry.time)+" · "+MainActivity.rub(r.entry.amount)+" · "+typeName(r.entry.type));selected.setChecked(r.selected);selected.setEnabled(!r.exact&&r.entry.counted()&&r.warning.isEmpty());selected.setOnCheckedChangeListener((v,checked)->{r.selected=checked;render();});add(box,selected);add(box,text(r.entry.merchant,15,true));
   if(r.exact)add(box,text("Уже импортировано",13,false));else if(r.possible)add(box,text("Возможно, уже есть в Казне — по умолчанию пропущено",13,false));if(!r.warning.isEmpty())add(box,text("Проверить: "+r.warning,13,false));
   gap(box);if(!r.exact)add(box,button("Проверить / исправить строку",()->editRow(r)));add(body,box);gap(body);
  }
  if(result.rows.size()>limit)add(body,button("Показать ещё строки",()->{limit+=50;render();}));
  gap(root);TextView save=button("Добавить выбранные: "+chosen,this::confirm);save.setEnabled(chosen>0);add(root,save);
 }
 void renderVerified(){
  int chosen=0,possible=0,exact=0;for(StatementParser.Row r:result.rows){if(r.exact)exact++;else if(r.possible)possible++;else if(r.selected)chosen++;}
  LinearLayout ok=col();ok.setPadding(dp(14),dp(14),dp(14),dp(14));ok.setBackgroundColor(MainActivity.WHITE);
  add(ok,text(synced?"✓ Выписка синхронизирована автоматически":result.creditStatement?"✓ Выписка кредитной карты проверена":"✓ Выписка проверена математически",18,true));gap(ok);
  if(!result.periodFrom.isEmpty()||!result.periodTo.isEmpty())add(ok,text("Период: "+result.periodFrom+" — "+result.periodTo,14,false));
  if(result.creditStatement){add(ok,text("Карта: •• "+(result.accountCard.isEmpty()?"не указана":result.accountCard),14,false));add(ok,text("Текущий долг: "+MainActivity.rub(result.creditDebt),16,true));add(ok,text("Доступно: "+MainActivity.rub(result.availableCredit),14,false));if(result.creditLimit>0)add(ok,text("Кредитный лимит: "+MainActivity.rub(result.creditLimit),14,false));if(result.pendingAmount>0)add(ok,text("Неподтверждённые операции: "+MainActivity.rub(result.pendingAmount),14,false));}
  else{if(!result.cardsSummary.isEmpty())add(ok,text("Карты: •• "+result.cardsSummary.replace(", ",", •• "),14,false));else add(ok,text("Карта: •• "+(result.accountCard.isEmpty()?"не указана":result.accountCard),14,false));add(ok,text("Начальный остаток: "+MainActivity.rub(result.openingBalance),14,false));add(ok,text("Поступления: "+MainActivity.rub(result.totalCredits),14,false));add(ok,text("Списания: "+MainActivity.rub(result.totalDebits),14,false));add(ok,text("Конечный остаток: "+MainActivity.rub(result.closingBalance),16,true));}
  gap(ok);add(ok,text(result.validation,13,false));add(body,ok);gap(body);
  if(synced){add(body,text("Добавлено операций: "+syncCounts[0]+" · уже были: "+syncCounts[1]+" · совпали с ранее записанными: "+syncCounts[2],14,true));gap(body);add(body,text(syncMessage,16,true));gap(body);add(body,text("Банк, период и счёт определены автоматически. Подтверждать каждую операцию не нужно.",13,false));gap(body);add(body,button("Готово",this::finish));return;}
  add(body,text("Новых операций: "+chosen+" · уже есть: "+exact+" · совпали с ранее записанными: "+possible,14,true));gap(body);add(body,button("Синхронизировать",this::importVerified));
 }
 void importVerified(){if(loading)return;loading=true;render();worker.execute(()->{try{syncCounts=syncVerified(result);synced=true;ui(()->{loading=false;render();});}catch(Exception ex){ui(()->{loading=false;error="Сохранение не выполнено. Изменения отменены.";render();});}});}
 String typeName(String type){for(int i=0;i<MainActivity.TYPES.length;i++)if(MainActivity.TYPES[i].equals(type))return MainActivity.TYPE_NAMES[i];return type;}
 void editRow(StatementParser.Row r){final long[] stagedDate={r.entry.time};LinearLayout p=col();p.setPadding(dp(16),dp(10),dp(16),dp(10));EditText amount=new EditText(this);amount.setHint("Сумма, ₽");amount.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);if(r.entry.amount>0)amount.setText(java.math.BigDecimal.valueOf(r.entry.amount,2).toPlainString());add(p,amount);EditText merchant=new EditText(this);merchant.setText(r.entry.merchant);merchant.setHint("Магазин или описание");add(p,merchant);TextView date=button(MainActivity.formatDate(r.entry.time),()->{});date.setOnClickListener(v->{java.time.ZonedDateTime z=java.time.Instant.ofEpochMilli(stagedDate[0]).atZone(java.time.ZoneId.systemDefault());new DatePickerDialog(this,(picker,y,m,day)->{stagedDate[0]=java.time.LocalDate.of(y,m+1,day).atTime(z.toLocalTime()).atZone(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli();date.setText(MainActivity.formatDate(stagedDate[0]));},z.getYear(),z.getMonthValue()-1,z.getDayOfMonth()).show();});add(p,date);Spinner type=new Spinner(this);type.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,MainActivity.TYPE_NAMES));type.setSelection(Arrays.asList(MainActivity.TYPES).indexOf(r.entry.type));add(p,type);TextView raw=text(r.entry.raw,12,false);raw.setTextIsSelectable(true);add(p,raw);ScrollView scroll=new ScrollView(this);scroll.addView(p);
  AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Строка "+r.number).setView(scroll).setNegativeButton("Отмена",null).setPositiveButton("Подтверждаю",null).create();dialog.setOnShowListener(d->dialog.getButton(-1).setOnClickListener(v->{try{String value=amount.getText().toString();if(!value.matches("\\d+(?:[.,]\\d{1,2})?"))throw new IllegalArgumentException();long a=BankParser.money(value);if(a<=0||a>10000000000000L||MainActivity.TYPES[type.getSelectedItemPosition()].equals("unknown"))throw new IllegalArgumentException();String m=merchant.getText().toString().trim();if(m.isEmpty()||m.length()>200)throw new IllegalArgumentException();r.entry.time=stagedDate[0];r.entry.amount=a;r.entry.type=MainActivity.TYPES[type.getSelectedItemPosition()];r.entry.merchant=m;r.entry.category=BankParser.category(m);r.entry.review=r.entry.type.startsWith("transfer")||r.entry.category.equals("Другое");r.warning="";r.possible=StatementParser.possible(r.entry,Store.get(this).all());r.selected=!r.possible;dialog.dismiss();render();}catch(Exception ex){amount.setError("Проверь сумму, описание и вид операции");}}));dialog.show();
 }
 void confirm(){List<StatementParser.Row> chosen=new ArrayList<>();for(StatementParser.Row r:result.rows)if(r.selected&&!r.exact)chosen.add(r);if(chosen.isEmpty())return;new AlertDialog.Builder(this).setTitle("Добавить "+chosen.size()+" операций?").setMessage("Выбранные строки попадут в статистику. Неотмеченные строки сохраняться не будут.").setNegativeButton("Отмена",null).setPositiveButton("Добавить",(d,w)->{loading=true;render();worker.execute(()->{try{int[] counts=Store.get(this).importRows(chosen);ui(()->{loading=false;new AlertDialog.Builder(this).setTitle("Импорт завершён").setMessage("Добавлено: "+counts[0]+".\nУже были или ранее удалены: "+counts[1]+".\nНовые совпадения: "+counts[2]+".").setPositiveButton("Готово",(x,y)->finish()).setOnCancelListener(x->finish()).show();});}catch(Exception ex){ui(()->{loading=false;error="Сохранение не выполнено. Изменения отменены.";render();});}});}).show();}
}
