package ru.kazna.app;
import java.util.*;
public final class Ledger {
 public long expenses,income,refunds,cash,own;public int reviewCount;
 public final Map<String,Long> categories=new LinkedHashMap<>();
 public Ledger(List<Entry> entries){for(Entry e:entries){
  if(e.review)reviewCount++;
  if(!e.counted())continue;
  if(e.ownTransfer()){own+=e.amount;continue;}
  if(e.type.equals("cash")){cash+=e.amount;continue;}
  if(e.outgoing()){expenses+=e.amount;categories.put(e.category,categories.getOrDefault(e.category,0L)+e.amount);}
  if(e.incoming())income+=e.amount;
  if(e.type.equals("refund"))refunds+=e.amount;
 }}
 public long netExpenses(){return expenses-refunds;}
}
