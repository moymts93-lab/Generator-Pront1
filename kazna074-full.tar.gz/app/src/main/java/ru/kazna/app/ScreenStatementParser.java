package ru.kazna.app;
import java.time.*;import java.time.format.*;import java.util.*;import java.util.regex.*;
/** Prototype for readable history rows. Missing dates or signed ruble amounts are never guessed. */
public final class ScreenStatementParser {
 static final String[] MONTHS={"января","февраля","марта","апреля","мая","июня","июля","августа","сентября","октября","ноября","декабря"};
 public static boolean safeHistory(String text){String low=text.toLowerCase(new Locale("ru"));return (low.contains("история")||low.contains("операции"))&&!Pattern.compile("(?iu)(\\bпароль\\b|пин.?код|код подтверждения|\\bвойти\\b|\\bвход\\b|отпечаток|секретный код)").matcher(text).find();}
 static LocalDate day(String value,LocalDate today){String s=value.trim().toLowerCase(new Locale("ru"));if(s.equals("сегодня"))return today;if(s.equals("вчера"))return today.minusDays(1);
  Matcher full=StatementParser.DATE.matcher(s);if(full.matches())try{return Instant.ofEpochMilli(StatementParser.date(s)).atZone(ZoneId.systemDefault()).toLocalDate();}catch(Exception ignored){}
  for(int i=0;i<12;i++){Matcher m=Pattern.compile("^(\\d{1,2}) "+MONTHS[i]+"(?: (\\d{4}))?$",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(s);if(m.matches())try{LocalDate d=LocalDate.of(m.group(2)==null?today.getYear():Integer.parseInt(m.group(2)),i+1,Integer.parseInt(m.group(1)));if(m.group(2)==null&&d.isAfter(today))d=d.minusYears(1);return d;}catch(Exception ignored){}}
  return null;
 }
 public static StatementParser.Result parse(List<String> pieces,LocalDate today,String document){StringBuilder normalized=new StringBuilder();LocalDate current=null;StringBuilder pending=new StringBuilder();int dropped=0;
  for(String piece:pieces)for(String line:piece.split("\\r?\\n")){
   String s=line.trim();if(s.isEmpty())continue;LocalDate date=day(s,today);if(date!=null){current=date;pending.setLength(0);continue;}
   if(StatementParser.DATE.matcher(s).find()&&StatementParser.SIGNED_RUB.matcher(s).find()){normalized.append(s).append('\n');pending.setLength(0);continue;}
   Matcher amount=StatementParser.SIGNED_RUB.matcher(s);
   if(amount.find()){
    if(current!=null){normalized.append(current.format(DateTimeFormatter.ofPattern("dd.MM.uuuu"))).append(' ').append(pending).append(' ').append(s).append('\n');}else dropped++;
    pending.setLength(0);
   }else if(!s.matches("(?iu).*(история|операции|поиск|фильтр|счета|все карты|главная|платежи).*")&&!s.matches("\\d{2}:\\d{2}")){
    if(pending.length()+s.length()<250)pending.append(s).append(' ');
   }
  }
  StatementParser.Result result=StatementParser.text(normalized.toString(),"Сбер",document);result.skipped+=dropped;result.note="Пробное чтение видимой истории Сбера. Проверь дату, описание, сумму и направление каждой строки. Поддерживаются только открытые текстовые элементы; отсутствующие даты и суммы не восстанавливаются.";return result;
 }
}
