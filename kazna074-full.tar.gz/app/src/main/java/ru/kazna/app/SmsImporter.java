package ru.kazna.app;
import android.content.Context;import android.database.Cursor;import android.provider.Telephony;
public final class SmsImporter{
 public static int[] run(Context context,long from){int found=0,added=0,review=0;try(Cursor c=context.getContentResolver().query(Telephony.Sms.Inbox.CONTENT_URI,new String[]{"address","body","date","date_sent"},"date>=?",new String[]{Long.toString(from)},"date ASC")){if(c==null)throw new IllegalStateException();while(c.moveToNext()){if(BankParser.bank(c.getString(0))==null)continue;long date=c.getLong(3)>0?c.getLong(3):c.getLong(2);Entry e=BankParser.parse(c.getString(0),c.getString(1),date,"sms");if(e==null)continue;found++;if(Store.get(context).add(e)){added++;if(e.review)review++;}}}return new int[]{found,added,review};}
}
