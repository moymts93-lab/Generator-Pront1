package ru.kazna.app;
import android.app.Notification;
import android.content.SharedPreferences;
import android.os.*;
import android.service.notification.*;
import java.util.*;
import java.util.concurrent.*;

/** Keeps the original component name so an existing notification grant survives an update. */
public class SmsNotificationService extends NotificationListenerService {
 private static final List<String> SMS_APPS=Arrays.asList("com.google.android.apps.messaging","com.samsung.android.messaging","com.android.mms");
 private final ExecutorService worker=Executors.newSingleThreadExecutor();
 public static volatile boolean connected;
 @Override public void onListenerConnected(){connected=true;}
 @Override public void onListenerDisconnected(){connected=false;}
 @Override public void onDestroy(){connected=false;worker.shutdown();super.onDestroy();}
 @Override public void onNotificationPosted(StatusBarNotification sbn){
  if(sbn==null)return;
  SharedPreferences prefs=getSharedPreferences("kazna",0);
  String mode=prefs.getString("mode","off"),pkg=sbn.getPackageName();
  boolean bank=mode.equals("bank_push")&&BankPushParser.sender(pkg)!=null;
  boolean sms=mode.equals("notifications")&&SMS_APPS.contains(pkg);
  if(!bank&&!sms)return;
  Notification n=sbn.getNotification();
  if(n==null||(n.flags&Notification.FLAG_GROUP_SUMMARY)!=0||n.extras==null)return;
  Bundle b=n.extras;
  String title=str(b.getCharSequence(Notification.EXTRA_TITLE));
  long date=n.when>0&&n.when<=sbn.getPostTime()+60000?n.when:sbn.getPostTime();
  final List<Entry> found=new ArrayList<>();
  if(bank){
   // One notification is one candidate. Do not join InboxStyle lists of different purchases.
   String body=str(b.getCharSequence(Notification.EXTRA_BIG_TEXT));
   if(body.isEmpty())body=str(b.getCharSequence(Notification.EXTRA_TEXT));
   if(body.isEmpty()){
    CharSequence[] lines=b.getCharSequenceArray(Notification.EXTRA_TEXT_LINES);
    if(lines!=null&&lines.length==1)body=str(lines[0]);
    else if(lines!=null&&lines.length>1){status("Сводное уведомление: ожидаю отдельные операции",pkg);return;}
   }
   Entry e=BankPushParser.parse(pkg,title,body,date,sbn.getKey());if(e!=null)found.add(e);
  }else{
   List<Notification.MessagingStyle.Message> messages=Collections.emptyList();
   if(Build.VERSION.SDK_INT>=28){
    try{Notification.Style style=Notification.Builder.recoverBuilder(this,n).getStyle();if(style instanceof Notification.MessagingStyle)messages=((Notification.MessagingStyle)style).getMessages();}catch(RuntimeException ignored){}
   }
   if(!messages.isEmpty()){
    for(Notification.MessagingStyle.Message m:messages){
     Entry e=BankParser.parse(m.getSender()==null?title:m.getSender().toString(),str(m.getText()),m.getTimestamp()>0?m.getTimestamp():date,"notification");if(e!=null)found.add(e);
    }
   }else{
    CharSequence body=b.getCharSequence(Notification.EXTRA_BIG_TEXT);if(body==null||body.length()==0)body=b.getCharSequence(Notification.EXTRA_TEXT);
    Entry e=BankParser.parse(title,str(body),date,"notification");if(e!=null)found.add(e);
   }
  }
  if(worker.isShutdown())return;
  worker.execute(()->{
   if(!mode.equals(prefs.getString("mode","off")))return;
   try{int added=0;String detail="";Store store=Store.get(this);for(Entry e:found){Store.Account before=store.account(e.bank,e.card);long oldBalance=before!=null&&before.hasBalance?before.balance:Long.MIN_VALUE;if(store.add(e)){added++;Store.Account after=store.account(e.bank,e.card);String sign=e.direction()>0?"+":e.direction()<0?"−":"";detail=e.bank+" · "+typeName(e.type)+" "+sign+money(e.amount);if(after!=null&&after.hasBalance&&(oldBalance==Long.MIN_VALUE||after.balance!=oldBalance))detail+=" · баланс "+money(after.balance);else if(after==null||!after.hasBalance)detail+=" · баланс не задан";}}
    if(bank)status(found.isEmpty()?"Не распознано: формат пуша не поддерживается или текст скрыт":added>0?detail:"Повторное уведомление пропущено",pkg);
   }catch(RuntimeException ex){if(bank)status("Не удалось сохранить операцию: "+ex.getClass().getSimpleName(),pkg);}
  });
 }

 private static String typeName(String type){if("income".equals(type))return "доход";if("refund".equals(type))return "возврат";if("expense".equals(type))return "расход";if(type!=null&&type.startsWith("transfer"))return "перевод";if(type!=null&&type.startsWith("own_"))return "между своими";return type==null?"операция":type;}
 private static String money(long kopecks){java.text.NumberFormat n=java.text.NumberFormat.getNumberInstance(new java.util.Locale("ru"));n.setMinimumFractionDigits(kopecks%100==0?0:2);n.setMaximumFractionDigits(2);return n.format(kopecks/100.0)+" ₽";}
 private void status(String result,String pkg){getSharedPreferences("kazna",0).edit().putLong("push_seen",System.currentTimeMillis()).putString("push_bank",BankParser.bank(BankPushParser.sender(pkg))).putString("push_result",result).apply();}
 static String str(CharSequence s){return s==null?"":s.toString();}
}
