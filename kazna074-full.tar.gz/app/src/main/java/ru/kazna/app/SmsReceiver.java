package ru.kazna.app;
import android.content.*;import android.provider.Telephony;import android.telephony.SmsMessage;
public class SmsReceiver extends BroadcastReceiver{
 @Override public void onReceive(Context c,Intent i){if(!Telephony.Sms.Intents.SMS_RECEIVED_ACTION.equals(i.getAction())||!c.getSharedPreferences("kazna",0).getString("mode","off").equals("sms"))return;SmsMessage[] parts=Telephony.Sms.Intents.getMessagesFromIntent(i);if(parts==null||parts.length==0)return;String sender=parts[0].getOriginatingAddress();if(BankParser.bank(sender)==null)return;StringBuilder body=new StringBuilder();for(SmsMessage p:parts)body.append(p.getMessageBody());Entry e=BankParser.parse(sender,body.toString(),parts[0].getTimestampMillis(),"sms");if(e==null)return;PendingResult result=goAsync();new Thread(()->{try{Store.get(c).add(e);}finally{result.finish();}},"kazna-sms").start();}
}
