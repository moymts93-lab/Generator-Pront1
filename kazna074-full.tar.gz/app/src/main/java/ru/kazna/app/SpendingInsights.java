package ru.kazna.app;
import java.time.*;import java.time.temporal.ChronoUnit;import java.util.*;
/** Deterministic local observations, not assumptions about the user's necessities. */
public final class SpendingInsights {
 public final List<Entry> current=new ArrayList<>(),previous=new ArrayList<>();
 public final Map<String,List<Entry>> small=new LinkedHashMap<>(),recurring=new LinkedHashMap<>();
 public final List<String> growth=new ArrayList<>();
 private final ZoneId zone;
 public final Ledger now,before;public final int days,previousDays;public final long forecast;
 public final boolean ongoing;public int activeDays;public long smallTotal,recurringMonthlyTotal;
 public SpendingInsights(List<Entry> entries,YearMonth month,LocalDate today,ZoneId zone,long smallLimit){
  this.zone=zone;ongoing=month.equals(YearMonth.from(today));days=ongoing?today.getDayOfMonth():month.lengthOfMonth();
  // Compare equal numbers of calendar days, including February and leap years.
  int comparable=Math.min(days,month.minusMonths(1).lengthOfMonth());previousDays=comparable;
  List<Entry> comparison=new ArrayList<>();Set<LocalDate> active=new HashSet<>();
  Map<String,List<Entry>> merchants=new HashMap<>();
  for(Entry e:entries){LocalDate date=Instant.ofEpochMilli(e.time).atZone(zone).toLocalDate();if(date.isAfter(today))continue;
   YearMonth ym=YearMonth.from(date);
   if(ym.equals(month)){
    current.add(e);if(date.getDayOfMonth()<=comparable)comparison.add(e);
    if(e.counted()&&e.outgoing()&&!e.ownTransfer()){
     active.add(date);
     if(e.type.equals("expense")&&e.amount<=smallLimit){small.computeIfAbsent(e.category,k->new ArrayList<>()).add(e);smallTotal+=e.amount;}
    }
   }
   if(ym.equals(month.minusMonths(1))&&date.getDayOfMonth()<=comparable)previous.add(e);
   if(e.counted()&&e.type.equals("expense")&&!e.merchant.isEmpty()&&!date.isBefore(month.minusMonths(5).atDay(1))&&!date.isAfter(month.atEndOfMonth())){
    String key=recurringKey(e.merchant);if(!key.isEmpty())merchants.computeIfAbsent(key,k->new ArrayList<>()).add(e);
   }
  }
  now=new Ledger(current);before=new Ledger(previous);Ledger comparableNow=new Ledger(comparison);activeDays=active.size();
  forecast=ongoing&&days>=7&&activeDays>=3?Math.round(now.expenses*(double)month.lengthOfMonth()/days):-1;
  for(Map.Entry<String,Long> row:ExpenseAnalysis.sorted(comparableNow.categories)){
   long prev=before.categories.getOrDefault(row.getKey(),0L);if(prev>0&&row.getValue()>prev)growth.add(row.getKey());
  }
  for(Map.Entry<String,List<Entry>> item:merchants.entrySet()){
   List<Entry> sorted=item.getValue();sorted.sort(Comparator.comparingLong(e->e.time));
   if(sorted.size()<3)continue;
   // Require three distinct monthly intervals with similar amounts; ordinary daily shops are excluded.
   for(int i=sorted.size()-1;i>=2;i--){
    Entry a=sorted.get(i-2),b=sorted.get(i-1),c=sorted.get(i);
    LocalDate da=Instant.ofEpochMilli(a.time).atZone(zone).toLocalDate(),db=Instant.ofEpochMilli(b.time).atZone(zone).toLocalDate(),dc=Instant.ofEpochMilli(c.time).atZone(zone).toLocalDate();
    long ab=ChronoUnit.DAYS.between(da,db),bc=ChronoUnit.DAYS.between(db,dc);
    YearMonth lastMonth=YearMonth.from(dc);boolean relevant=lastMonth.equals(month)||lastMonth.equals(month.minusMonths(1));
    long tolerance=Math.max(30000L,b.amount/4); // 300 ₽ or 25%: covers variable phone/internet bills.
    if(ab>=25&&ab<=35&&bc>=25&&bc<=35&&Math.abs(a.amount-b.amount)<=tolerance&&Math.abs(c.amount-b.amount)<=tolerance&&relevant){
     recurring.put(item.getKey(),new ArrayList<>(Arrays.asList(a,b,c)));recurringMonthlyTotal+=c.amount;break;
    }
   }
  }
 }
 public static String recurringKey(String merchant){String s=merchant==null?"":merchant.toLowerCase(new Locale("ru")).trim();s=s.replaceAll("(?iu)\\b(rus|novosibirsk|moscow|online|qr)\\b","").replaceAll("[^a-zа-я0-9]+"," ").replaceAll("\\s+"," ").trim();return s;}
 public long currentComparable(String category){long sum=0;for(Entry e:current)if(e.counted()&&e.outgoing()&&!e.ownTransfer()&&e.category.equals(category)&&Instant.ofEpochMilli(e.time).atZone(zone).getDayOfMonth()<=previousDays)sum+=e.amount;return sum;}
 public static long saving(long baseline,int percent){if(baseline<0||percent<0||percent>100)throw new IllegalArgumentException();return baseline/100*percent+(baseline%100)*percent/100;}
}
