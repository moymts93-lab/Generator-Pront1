package ru.kazna.app;
import android.content.Context;import android.net.Uri;import java.io.*;import java.nio.*;import java.nio.charset.*;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.io.MemoryUsageSetting;

public final class StatementFiles {
 public static final class Detected{
  public final String bank;public final StatementParser.Result result;
  Detected(String bank,StatementParser.Result result){this.bank=bank;this.result=result;}
 }
 private static byte[] data(Context c,Uri uri)throws Exception{
  try(InputStream in=c.getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
   if(in==null)throw new IOException("Файл не открыт");byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>10*1024*1024)throw new IOException("Файл больше 10 МБ");out.write(b,0,n);}return out.toByteArray();
  }
 }
 private static String pdfText(Context c,byte[] data)throws Exception{
  PDFBoxResourceLoader.init(c.getApplicationContext());
  try(PDDocument document=PDDocument.load(new ByteArrayInputStream(data),MemoryUsageSetting.setupMixed(8*1024*1024L,32*1024*1024L).setTempDir(c.getCacheDir()))){
   if(document.isEncrypted())throw new IOException("Сохрани выписку без пароля");if(document.getNumberOfPages()>100)throw new IOException("Нужно не больше 100 страниц");
   PDFTextStripper stripper=new PDFTextStripper();stripper.setSortByPosition(true);stripper.setLineSeparator("\n");stripper.setWordSeparator(" ");
   StringWriter writer=new StringWriter(){@Override public void write(String s,int off,int len){if(getBuffer().length()+len>2000000)throw new IllegalArgumentException("Слишком много текста");super.write(s,off,len);}};
   stripper.writeText(document,writer);String text=writer.toString();if(text.trim().length()<20)throw new IOException("В PDF нет читаемого текста. Сканированные выписки пока не поддерживаются.");return text;
  }
 }
 private static String plainText(byte[] data)throws Exception{
  String text;try{text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(data)).toString();}catch(CharacterCodingException ex){text=Charset.forName("windows-1251").decode(ByteBuffer.wrap(data)).toString();}
  if(text.indexOf('\0')>=0)throw new IOException("Нужен PDF, CSV или текстовый файл");return text;
 }
 private static StatementParser.Result parse(String text,String bank,String hash,boolean pdf){
  if(!pdf&&(text.contains(";")||text.contains("\t")||text.contains(","))){try{return StatementParser.csv(text,bank,hash);}catch(IllegalArgumentException ex){StatementParser.Result r=StatementParser.text(text,bank,hash);if(r.rows.isEmpty())throw ex;return r;}}
  return StatementParser.text(text,bank,hash);
 }
 public static Detected readAuto(Context c,Uri uri)throws Exception{
  byte[] bytes=data(c,uri);String hash=BankParser.fingerprint(java.util.Base64.getEncoder().encodeToString(bytes));boolean pdf=bytes.length>4&&bytes[0]=='%'&&bytes[1]=='P'&&bytes[2]=='D'&&bytes[3]=='F';String text=pdf?pdfText(c,bytes):plainText(bytes);
  String bank=StatementParser.detectBank(text);if(bank==null)throw new IOException("Не удалось автоматически определить банк. Нужна выписка Сбера, Т-Банка или Альфа-Банка с читаемым текстом.");
  return new Detected(bank,parse(text,bank,hash,pdf));
 }
 public static StatementParser.Result read(Context c,Uri uri,String bank)throws Exception{
  byte[] bytes=data(c,uri);String hash=BankParser.fingerprint(java.util.Base64.getEncoder().encodeToString(bytes));boolean pdf=bytes.length>4&&bytes[0]=='%'&&bytes[1]=='P'&&bytes[2]=='D'&&bytes[3]=='F';String text=pdf?pdfText(c,bytes):plainText(bytes);return parse(text,bank,hash,pdf);
 }
}
