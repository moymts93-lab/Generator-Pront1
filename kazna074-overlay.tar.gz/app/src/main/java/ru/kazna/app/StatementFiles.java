package ru.kazna.app;
import android.content.Context;import android.net.Uri;import java.io.*;import java.nio.*;import java.nio.charset.*;import java.util.Locale;
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader;
import com.tom_roush.pdfbox.pdmodel.PDDocument;
import com.tom_roush.pdfbox.text.PDFTextStripper;
import com.tom_roush.pdfbox.io.MemoryUsageSetting;
public final class StatementFiles {
 public static final class AutoResult{public final String bank;public final StatementParser.Result result;AutoResult(String b,StatementParser.Result r){bank=b;result=r;}}
 private static byte[] bytes(Context c,Uri uri)throws Exception{
  try(InputStream in=c.getContentResolver().openInputStream(uri);ByteArrayOutputStream out=new ByteArrayOutputStream()){
   if(in==null)throw new IOException("Файл не открыт");byte[] b=new byte[8192];int n;while((n=in.read(b))!=-1){if(out.size()+n>10*1024*1024)throw new IOException("Файл больше 10 МБ");out.write(b,0,n);}return out.toByteArray();
  }
 }
 private static String text(Context c,byte[] data)throws Exception{
  boolean pdf=data.length>4&&data[0]=='%'&&data[1]=='P'&&data[2]=='D'&&data[3]=='F';
  if(pdf){PDFBoxResourceLoader.init(c.getApplicationContext());
   try(PDDocument document=PDDocument.load(new ByteArrayInputStream(data),MemoryUsageSetting.setupMixed(8*1024*1024L,32*1024*1024L).setTempDir(c.getCacheDir()))){
    if(document.isEncrypted())throw new IOException("Сохрани выписку без пароля");if(document.getNumberOfPages()>100)throw new IOException("Нужно не больше 100 страниц");
    PDFTextStripper stripper=new PDFTextStripper();stripper.setSortByPosition(true);stripper.setLineSeparator("\n");stripper.setWordSeparator(" ");
    StringWriter writer=new StringWriter(){@Override public void write(String s,int off,int len){if(getBuffer().length()+len>2000000)throw new IllegalArgumentException("Слишком много текста");super.write(s,off,len);}};
    stripper.writeText(document,writer);String text=writer.toString();if(text.trim().length()<20)throw new IOException("В PDF нет читаемого текста. Нужна обычная PDF-выписка банка, не фотография документа.");return text;
   }
  }
  String text;try{text=StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(data)).toString();}catch(CharacterCodingException ex){text=Charset.forName("windows-1251").decode(ByteBuffer.wrap(data)).toString();}
  if(text.indexOf('\0')>=0)throw new IOException("Нужен PDF, CSV или текстовый файл");return text;
 }
 public static String detectBank(String text)throws IOException{
  String low=text.toLowerCase(new Locale("ru")).replace('ё','е');int sber=0,tbank=0,alfa=0;
  if(low.contains("сбербанк")||low.contains("сбер"))sber+=2;if(low.contains("выписка по счету дебетовой карты"))sber+=5;if(low.contains("остаток средств")&&low.contains("итого по операциям за период"))sber+=4;
  if(low.contains("т-банк")||low.contains("тинькофф"))tbank+=3;if(low.contains("выписка по договору"))tbank+=5;if(low.contains("операции по карте")&&low.contains("баланс на"))tbank+=4;
  if(low.contains("альфа-банк")||low.contains("alfabank"))alfa+=3;if(low.contains("счет кредитной карты"))alfa+=5;if(low.contains("общая задолженность к погашению")&&low.contains("операции по счету"))alfa+=5;
  int best=Math.max(sber,Math.max(tbank,alfa));if(best<5)throw new IOException("Не удалось определить банк. Сейчас автоматически поддерживаются PDF-выписки Сбера, Т-Банка и кредитной карты Альфа-Банка.");
  if(sber==best&&sber>tbank&&sber>alfa)return "Сбер";if(tbank==best&&tbank>sber&&tbank>alfa)return "Т-Банк";if(alfa==best&&alfa>sber&&alfa>tbank)return "Альфа-Банк";
  throw new IOException("Банк определился неоднозначно. Выгрузи отдельную выписку одного банка.");
 }
 private static StatementParser.Result parse(String text,String bank,String hash){
  if(text.contains(";")||text.contains("\t")||text.contains(",")){try{return StatementParser.csv(text,bank,hash);}catch(IllegalArgumentException ex){StatementParser.Result r=StatementParser.text(text,bank,hash);if(r.rows.isEmpty())throw ex;return r;}}
  return StatementParser.text(text,bank,hash);
 }
 public static AutoResult readAuto(Context c,Uri uri)throws Exception{byte[] data=bytes(c,uri);String hash=BankParser.fingerprint(java.util.Base64.getEncoder().encodeToString(data));String text=text(c,data);String bank=detectBank(text);return new AutoResult(bank,parse(text,bank,hash));}
 public static StatementParser.Result read(Context c,Uri uri,String bank)throws Exception{byte[] data=bytes(c,uri);String hash=BankParser.fingerprint(java.util.Base64.getEncoder().encodeToString(data));return parse(text(c,data),bank,hash);}
}
