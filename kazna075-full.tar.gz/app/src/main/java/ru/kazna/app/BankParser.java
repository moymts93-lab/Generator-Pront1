package ru.kazna.app;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.Normalizer;
import java.util.Locale;
import java.util.regex.*;

/** Conservative parser; fixtures are synthetic, not a claim of all-bank format coverage. */
public final class BankParser {
 public static final String[] CATEGORIES={"Продукты","Кафе","Транспорт","Дом","Покупки","Здоровье","Развлечения","Подписки","Связь","Комиссии","Кредиты","Доходы","Переводы","Наличные","Другое"};
 private static final int FLAGS=Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE;
 private static final Pattern MONEY=Pattern.compile("(?<![\\d.,])([+−-]?\\s*\\d+(?:[ \\u00a0\\u202f]\\d{3})*(?:[.,]\\d{1,2})?)\\s*(₽|руб(?:лей|ля|ль)?\\.?|rub|rur|р\\.?)(?![a-zа-я])",FLAGS);
 private static final Pattern OP=Pattern.compile("покупк[аиу]?|оплат[ауы]|списани[ея]|списано|сняти[ея]|выдача наличных|внесени[ея] наличных|внесено наличных|возврат|возвращено|зачислени[ея]|зачислено|пополнени[ея]|поступлени[ея]|поступило|заработная плата|зарплат[аы]?|аванс|преми[яи]|перевод|перевели|переведено|salary|payment|purchase|refund|cash withdrawal|deposit|credited",FLAGS);
 private static final Pattern CARD=Pattern.compile("(?:\\b(?:visa|mastercard|master|mir|мир|maestro|сч[её]т|карта|карту|карты|card)\\s*[*•xх:№-]*\\s*|[*•]{1,4})(\\d{4})(?!\\d)",FLAGS);
 private static String norm(String s){return Normalizer.normalize(s==null?"":s,Normalizer.Form.NFKC).replace('\u00a0',' ').replace('\u202f',' ').trim();}
 public static String bank(String sender){String s=norm(sender).toLowerCase(Locale.ROOT).replaceAll("[ _-]","");if(s.equals("900")||s.equals("sberbank")||s.equals("sber")||s.equals("сбербанк"))return "Сбер";if(s.equals("tbank")||s.equals("tinkoff")||s.equals("tinkoffbank")||s.equals("тинькофф")||s.equals("тбанк"))return "Т-Банк";if(s.equals("alfabank")||s.equals("alfa")||s.equals("альфабанк")||s.equals("альфа"))return "Альфа-Банк";return null;}
 public static long money(String s){return new BigDecimal(s.replaceAll("[\\s\\u00a0\\u202f+−-]","").replace(',','.')).movePointRight(2).longValueExact();}
 private static String otherBank(String current,String low){
  if(!"Т-Банк".equals(current)&&low.matches("(?s).*(t-bank|т-банк|tinkoff|тинькофф).*"))return "Т-Банк";
  if(!"Альфа-Банк".equals(current)&&low.matches("(?s).*(альфа[- ]?банк|alfabank|alfa bank).*"))return "Альфа-Банк";
  if(!"Сбер".equals(current)&&low.matches("(?s).*(sberbank|sber|сбербанк|сбер).*"))return "Сбер";
  return "";
 }
 public static Entry parse(String sender,String text,long time,String source){
  String bank=bank(sender);if(bank==null||text==null||text.length()>6000)return null;
  String s=norm(text),low=s.toLowerCase(Locale.ROOT);
  if(Pattern.compile("(?:код|пароль|otp|code)(?:\\s|:|-|\\d)|никому не сообщ|не сообщайте|для подтверждения|подтвердите|подтверждение покупки|подтверждение перевода|отказ|отклон|не выполн|не прош|недостаточно|не удалось|заявка|запрос на|планируется|предстоит|будет списан|пополните|оплатите|к оплате|напоминаем|предлагаем|одобрен|погасите|получите|получи |кэшбэк до|кешбэк до|скидк|ожидает подтверждения|ожидает обработки|в обработке|обрабатывается|запланирован",FLAGS).matcher(low).find())return null;
  boolean salaryLike=low.matches("(?s).*(заработная плата|зарплат[аы]?|аванс|преми[яи]|salary).*");
  boolean cashDepositLike=low.matches("(?s).*(внесение наличных|пополнение наличными|пополнение через (?:терминал|банкомат)|внесено через (?:терминал|банкомат)|cash deposit).*");
  Matcher op=OP.matcher(s);boolean hasOp=op.find();if(!hasOp&&!salaryLike)return null;
  Entry e=new Entry();e.bank=bank;e.time=time;e.raw=s;e.source=source;e.key=fingerprint(bank+"|"+time+"|"+s);
  Matcher card=CARD.matcher(s);if(card.find())e.card=card.group(1);
  int start=hasOp?op.start():0,end=hasOp?op.end():0,cutoff=s.length();
  Matcher balance=Pattern.compile("баланс|остаток|доступно|доступный|balance|комиссия",FLAGS).matcher(s);
  while(balance.find())if(balance.start()>=end){cutoff=balance.start();break;}
  String transaction=s.substring(start,cutoff);Matcher mm=MONEY.matcher(transaction);
  if(!mm.find()&&salaryLike){transaction=s.substring(0,cutoff);mm=MONEY.matcher(transaction);}
  if(mm.find(0)){
   try{e.amount=money(mm.group(1));}catch(Exception ignored){e.amount=0;}
   if(salaryLike)e.merchant="Зарплата";
   else{e.merchant=clean(transaction.substring(mm.end()));if(e.merchant.isEmpty())e.merchant=clean(transaction.substring(Math.min(end-start,transaction.length()),mm.start()));}
  }
  String kind=transaction.toLowerCase(Locale.ROOT);
  if(kind.matches("(?s).*(возврат|возвращено|refund).*"))e.type="refund";
  else if(kind.matches("(?s).*(между своими|на свой сч[её]т|со своего сч[её]та|себе).*")){e.type="own";e.category="Переводы";}
  else if(kind.matches("(?s).*(перевод|перевели|переведено).*")){
   boolean incoming=kind.matches("(?s).*(перевод от|перевод из|перевели вам|входящ|зачисл|поступ).*");
   String other=otherBank(bank,low);boolean otherOwnBank=!other.isEmpty();
   e.type=otherOwnBank?(incoming?"own_in":"own_out"):(incoming?"transfer_in":"transfer_out");e.category="Переводы";e.review=!otherOwnBank;if(otherOwnBank)e.counterparty=other;
  }
  else if(kind.matches("(?s).*(внесени[ея] наличных|внесено наличных|пополнение наличными|через банкомат|через терминал).*")){e.type="own_in";e.category="Наличные";e.review=false;e.counterparty="Наличные";}
  else if(kind.matches("(?s).*(зачислен|пополнен|поступ|deposit|credited|salary).*")||salaryLike)e.type="income";
  String detectedOther=otherBank(bank,low);
  if(cashDepositLike){e.type="own_in";e.category="Переводы";e.review=false;e.counterparty="Наличные";}
  if(!cashDepositLike&&!detectedOther.isEmpty()&&e.type.equals("income")&&kind.matches("(?s).*(зачислен|пополнен|поступ|deposit|credited).*")&&!salaryLike){e.type="own_in";e.category="Переводы";e.review=false;e.counterparty=detectedOther;}
  if(kind.matches("(?s).*(сняти|выдача наличных|cash withdrawal).*")){e.type="cash";e.category="Наличные";e.counterparty="Наличные";}
  if(low.contains("branch karta-credit")){e.type="own_out";e.category="Кредиты";e.review=false;}
  if(low.contains("mobile bank: komissiya"))e.category="Комиссии";
  if(e.type.equals("income")&&salaryLike){e.category="Доходы";e.review=false;}
  if(e.category.equals("Другое"))e.category=category(e.merchant);
  Matcher bm=Pattern.compile("(?:баланс|остаток|доступно|доступный остаток|balance)\\s*[:=]?\\s*([0-9]+(?:[ \u00a0\u202f][0-9]{3})*(?:[.,][0-9]{1,2})?)\\s*(?:₽|руб\\.?|rub|rur|р\\.)?",FLAGS).matcher(s);
  if(bm.find())try{e.balanceAfter=money(bm.group(1));}catch(Exception ignored){}
  if(e.amount<=0||e.amount>10000000000000L||kind.matches("(?s).*(\\b(?:usd|eur|cny|kzt)\\b|[$€¥]).*")){e.amount=0;e.type="unknown";e.review=true;}
  if(!e.type.equals("refund")&&low.matches("(?s).*(отмена покупк|отмена операции|операция отменена|покупка отменена).*")){e.type="unknown";e.review=true;}
  if(e.merchant.length()<2)e.merchant=defaultTitle(e.type);
  if(e.category.equals("Другое")&&e.outgoing())e.review=true;
  return e;
 }
 private static String clean(String s){
  s=s.replaceAll("(?i)(?:\\b(?:visa|mastercard|mir|мир|card|карта|карты|карту)\\s*[*•: -]*\\d{4})","").replaceAll("[*•]{1,4}\\d{4}","");
  s=s.replaceAll("\\b\\d{2}\\.\\d{2}(?:\\.\\d{2,4})?\\b","").replaceAll("https?://\\S+","").replaceAll("\\b\\d{2}:\\d{2}(?::\\d{2})?\\b","");
  s=s.replaceAll("^[\\s.,;:—*-]+|[\\s.,;:—*-]+$","").replaceFirst("(?iu)^(?:в|за|магазин|место|на сумму|сумма|на)\\s+","").replaceFirst("(?iu)\\s+(?:на|на сумму|сумма)$","").trim();
  s=s.replaceAll("\\s+"," ").trim();
  return s.length()>100?s.substring(0,100):s;
 }
 public static String defaultTitle(String type){switch(type){case "income":return "Поступление";case "refund":return "Возврат";case "own":case "own_out":case "own_in":return "Между своими счетами";case "cash":return "Снятие наличных";case "transfer_in":return "Входящий перевод";case "transfer_out":return "Исходящий перевод";case "unknown":return "Проверить сообщение";default:return "Покупка";}}
 public static String category(String name){String s=name.toLowerCase(Locale.ROOT);
  if(s.matches(".*(пят[её]роч|pyater|magnit|магнит|lenta|лента|ашан|auchan|перекр[её]сток|perekrest|самокат|samokat|spar|монетка|ярче|yarche|jarche|svetofor).*"))return "Продукты";
  if(s.matches(".*(кофе|coffee|cafe|кафе|ресторан|вкусно|ростикс|rostic|burger|dodo|додо|столовая|utrennij keks|shaverma|zaytun|teriberka|belya).*"))return "Кафе";
  if(s.matches(".*(taxi|такси|uber|yandex[ .]*go|яндекс go|proezd|tpp_metro|метро|metro nsk|азс|gazpromneft|газпромнефть|лукойл|парковк).*"))return "Транспорт";
  if(s.matches(".*(аптека|apteka|pharm|farma|медицин|клиника|invitro|avicenna|mamadeti|veterinar|vetnora|enimalz|viaprim).*"))return "Здоровье";
  if(s.matches(".*(леруа|leman|лемана|hoff|жкх|квартплат|mosenergo).*"))return "Дом";
  if(s.matches(".*(ozon|озон|wildber|wb.ru|вайлдбер|днс|dns).*"))return "Покупки";
  if(s.matches(".*(yandex.plus|яндекс плюс|kinopoisk|кинопоиск|spotify|netflix|подписка|ivi\\.ru|okko|sota servers).*"))return "Подписки";
  if(s.matches(".*(мегафон|megafon|билайн|beeline|tele2|теле2|mts|мтс|ростелеком).*"))return "Связь";return "Другое";
 }
 public static String fingerprint(String s){try{byte[] bytes=MessageDigest.getInstance("SHA-256").digest(s.getBytes(StandardCharsets.UTF_8));StringBuilder h=new StringBuilder();for(byte v:bytes)h.append(String.format(Locale.ROOT,"%02x",v&255));return h.toString();}catch(Exception ex){throw new IllegalStateException(ex);}}
}
