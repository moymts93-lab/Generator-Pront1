package ru.kazna.app;

import java.time.*;
import java.util.*;
import java.util.regex.*;

/** Parses the visible debt details screen from a banking screenshot after OCR. */
public final class CreditScreenshotParser {
 public static final class Result {
  public long limitOrPrincipal,debt,principalDebt,interestDebt,payment,paymentPrincipal,paymentInterest,paymentDate,maturityDate;
  public int termMonths,remainingMonths;
  public String repaymentAccounts="";
  public int recognized;
  public boolean useful(){return limitOrPrincipal>0||debt>0||principalDebt>0||interestDebt>0||payment>0||paymentDate>0||termMonths>0||remainingMonths>0||!repaymentAccounts.isEmpty();}
 }
 private static final int F=Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE;
 private static final Pattern MONEY=Pattern.compile("([0-9][0-9 \\u00a0\\u202f]*(?:[,.][0-9]{1,2})?)\\s*(?:₽|р\\.?|руб(?:\\.|ля|лей)?)?",F);
 private static final Map<String,Integer> MONTHS=new HashMap<>();
 static{
  String[][] m={{"январ", "1"},{"феврал","2"},{"март","3"},{"апрел","4"},{"ма","5"},{"июн","6"},{"июл","7"},{"август","8"},{"сентябр","9"},{"октябр","10"},{"ноябр","11"},{"декабр","12"}};
  for(String[] x:m)MONTHS.put(x[0],Integer.parseInt(x[1]));
 }
 private CreditScreenshotParser(){}
 static String norm(String s){return s==null?"":s.replace('\u00a0',' ').replace('\u202f',' ').replace('ё','е').replace('Ё','Е').replaceAll("[ \\t]+"," ").trim();}
 static long money(String s){return BankParser.money(s.replace("₽","").replace("руб.","").replace("руб","").replace("р.","").trim());}
 static long after(String text,String labelRegex){Matcher l=Pattern.compile(labelRegex,F).matcher(text);if(!l.find())return 0;Matcher m=MONEY.matcher(text.substring(l.end(),Math.min(text.length(),l.end()+140)));return m.find()?money(m.group(1)):0;}
 static long secondInterest(String text){Matcher pay=Pattern.compile("ближайш[а-яё]*\\s+плат[её]ж",F).matcher(text);if(!pay.find())return 0;String tail=text.substring(pay.end());Matcher m=Pattern.compile("процент[а-яё]*\\s+"+MONEY.pattern(),F).matcher(tail);return m.find()?money(m.group(1)):0;}
 static long parseDate(String text,LocalDate today){
  Matcher pay=Pattern.compile("ближайш[а-яё]*\\s+плат[её]ж",F).matcher(text);if(!pay.find())return 0;
  String tail=text.substring(pay.end(),Math.min(text.length(),pay.end()+240));
  Matcher block=Pattern.compile("(?:[—–-]\\s*)?([0-3]?\\d)\\s+([А-Яа-яЁё]+)(?:\\s+(20\\d{2}))?",F).matcher(tail);
  while(block.find()){
   int day;try{day=Integer.parseInt(block.group(1));}catch(Exception ex){continue;}if(day<1||day>31)continue;
   String word=norm(block.group(2)).toLowerCase(new Locale("ru"));int month=0;for(Map.Entry<String,Integer> e:MONTHS.entrySet())if(word.startsWith(e.getKey())){month=e.getValue();break;}if(month==0)continue;
   int year=block.group(3)==null?today.getYear():Integer.parseInt(block.group(3));LocalDate d;try{d=LocalDate.of(year,month,day);}catch(Exception ex){continue;}if(block.group(3)==null&&d.isBefore(today.minusDays(1)))d=d.plusYears(1);return d.atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli();
  }return 0;
 }
 static int monthsAfter(String text,String regex){Matcher m=Pattern.compile(regex+"[\\s\\S]{0,80}?(\\d{1,3})\\s*(?:мес|месяц)",F).matcher(text);if(!m.find())return 0;try{return Integer.parseInt(m.group(1));}catch(Exception ex){return 0;}}
 static String accounts(String text){
  Matcher start=Pattern.compile("счет[аы]\\s+погашения",F).matcher(text);if(!start.find())return "";String tail=text.substring(start.end()).trim();if(tail.isEmpty())return "";
  String[] lines=tail.split("\\r?\\n");List<String> out=new ArrayList<>();String pending="";
  for(String raw:lines){String line=norm(raw);if(line.isEmpty())continue;if(line.length()>120)line=line.substring(0,120);if(line.matches("(?iu).*(?:[•*xх]{1,4}\\s*\\d{4}).*")){if(!pending.isEmpty())out.add(pending);pending=line;}else if(!pending.isEmpty()&&MONEY.matcher(line).find()){pending+=" "+line;out.add(pending);pending="";}else if(out.size()<4&&MONEY.matcher(line).find())out.add(line);if(out.size()>=4)break;}
  if(!pending.isEmpty()&&out.size()<4)out.add(pending);return String.join("\n",out);
 }
 public static Result parse(String ocr,LocalDate today){
  Result r=new Result();String text=norm(ocr).replace(". ",".\n"); // keep parser tolerant to OCR line flattening
  // Use the original line breaks where available for repayment accounts.
  String original=ocr==null?"":ocr.replace('\u00a0',' ').replace('\u202f',' ');
  r.limitOrPrincipal=after(text,"(?:сумм[аы]\\s+(?:кредита|займа)|кредитн[а-яё]*\\s+лимит|первоначальн[а-яё]*\\s+сумм[аы]|общ[а-яё]*\\s+сумм[аы])");
  r.debt=after(text,"задолженность\\s+на\\s+(?:сегодня|текущ[а-яё]*)");
  r.principalDebt=after(text,"основн[а-яё]*\\s+долг");
  r.interestDebt=after(text,"процент[а-яё]*(?=\\s+[0-9])");
  r.payment=after(text,"ближайш[а-яё]*\\s+плат[её]ж");
  r.paymentPrincipal=after(text,"в\\s+счет\\s+основн[а-яё]*\\s+долг");
  r.paymentInterest=secondInterest(text);
  r.paymentDate=parseDate(text,today);
  r.termMonths=monthsAfter(text,"(?:общий\\s+срок|срок\\s+(?:кредита|займа))");
  r.remainingMonths=monthsAfter(text,"(?:остал[а-яё]*|остаток\\s+срока|до\\s+конца)");
  r.repaymentAccounts=accounts(original);
  long[] vals={r.limitOrPrincipal,r.debt,r.principalDebt,r.interestDebt,r.payment,r.paymentPrincipal,r.paymentInterest,r.paymentDate};for(long v:vals)if(v>0)r.recognized++;if(r.termMonths>0)r.recognized++;if(r.remainingMonths>0)r.recognized++;if(!r.repaymentAccounts.isEmpty())r.recognized++;
  return r;
 }
}
