package ru.kazna.app;
import java.time.*;import java.time.format.*;import java.util.*;import java.util.regex.*;

/** Bank statement parser. Known bank formats are parsed deterministically; generic text stays conservative. */
public final class StatementParser {
 public static final class Row {public Entry entry;public String warning="";public boolean selected,possible,exact;public int number;}
 public static final class Result {
  public final List<Row> rows=new ArrayList<>();public int skipped;public String note="";
  public boolean hasSummary,verified,balanceChainVerified,creditStatement;public int balanceChainBreaks;public long openingBalance,totalCredits,totalDebits,closingBalance,parsedCredits,parsedDebits;
  public long availableCredit,creditDebt,creditLimit,pendingAmount;
  public String accountCard="",accountNumber="",periodFrom="",periodTo="",validation="",cardsSummary="",verificationMethod="";
 }
 static final Pattern DATE=Pattern.compile("(?<!\\d)(\\d{2}\\.\\d{2}\\.\\d{4}|\\d{4}-\\d{2}-\\d{2})(?:[ T]+(\\d{2}:\\d{2}(?::\\d{2})?))?(?!\\d)");
 static final Pattern MONEY=Pattern.compile("(?<![\\d.,])([+−–-]?\\s*\\d+(?:[ \\u00a0\\u202f]\\d{3})*(?:[.,]\\d{2}))\\s*(?:₽|руб\\.?|RUB|RUR)?(?![\\d.,])",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);
 static final Pattern SIGNED_RUB=Pattern.compile("([+−–-]\\s*\\d+(?:[ \\u00a0\\u202f]\\d{3})*(?:[.,]\\d{1,2})?)\\s*(?:₽|руб\\.?|RUB|RUR|р\\.)(?![a-zа-я])",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);
 static final Pattern SBER_PRIMARY=Pattern.compile("^\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s+(\\d{2}:\\d{2})\\s+(.+?)\\s+([+]?\\d+(?:[ \\u00a0\\u202f]\\d{3})*(?:,\\d{2}))\\s+(\\d+(?:[ \\u00a0\\u202f]\\d{3})*(?:,\\d{2}))\\s*$");
 static final Pattern SBER_PROCESS=Pattern.compile("^\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s+(\\d{6})\\s+(.+?)\\s*$");
 static String norm(String s){return s==null?"":s.replace('\u00a0',' ').replace('\u202f',' ').replace('−','-').replace('–','-').trim();}
 static String title(String s){return norm(s).toLowerCase(new Locale("ru")).replace('_',' ').replaceAll("\\s+"," ");}
 public static String detectBank(String text){
  String low=title(text);int sber=0,tbank=0,alfa=0;
  if(low.contains("выписка по счёту дебетовой карты")&&low.contains("итого по операциям за период"))sber+=100;
  if(low.contains("выписка по договору")&&low.contains("операции по карте")&&low.contains("баланс на"))tbank+=100;
  if(low.contains("счёт кредитной карты")&&low.contains("общая задолженность к погашению")&&low.contains("операции по счету"))alfa+=100;
  sber+=occ(low,"сбербанк")*5+occ(low,"sberbank")*5+occ(low,"сбер банк")*3;
  tbank+=occ(low,"т-банк")*5+occ(low,"т банк")*5+occ(low,"t-bank")*5+occ(low,"тинькофф")*4+occ(low,"tinkoff")*4;
  alfa+=occ(low,"альфа-банк")*5+occ(low,"альфа банк")*5+occ(low,"alfa-bank")*5+occ(low,"alfabank")*5;
  int max=Math.max(sber,Math.max(tbank,alfa));if(max<=0)return null;int winners=(sber==max?1:0)+(tbank==max?1:0)+(alfa==max?1:0);if(winners!=1)return null;return sber==max?"Сбер":tbank==max?"Т-Банк":"Альфа-Банк";
 }
 static int occ(String text,String token){int n=0,p=0;while((p=text.indexOf(token,p))>=0){n++;p+=token.length();}return n;}
 static String at(List<String> cells,int n){return n>=0&&n<cells.size()?norm(cells.get(n)):"";}
 static int col(List<String> h,String... names){for(String name:names)for(int i=0;i<h.size();i++)if(title(h.get(i)).equals(name))return i;return -1;}
 public static long date(String text){
  try{OffsetDateTime parsed=OffsetDateTime.parse(norm(text));if(parsed.getYear()>=2000&&!parsed.toLocalDate().isAfter(LocalDate.now().plusDays(1)))return parsed.toInstant().toEpochMilli();throw new IllegalArgumentException("Дата вне диапазона");}catch(DateTimeParseException ignored){}
  Matcher m=DATE.matcher(text);if(!m.find())throw new IllegalArgumentException("Нет даты");
  LocalDate d=LocalDate.parse(m.group(1),DateTimeFormatter.ofPattern(m.group(1).contains(".")?"dd.MM.uuuu":"uuuu-MM-dd").withResolverStyle(ResolverStyle.STRICT));
  if(d.getYear()<2000||d.isAfter(LocalDate.now().plusDays(1)))throw new IllegalArgumentException("Дата вне диапазона");
  LocalTime t=m.group(2)==null?LocalTime.NOON:LocalTime.parse(m.group(2));return d.atTime(t).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
 }
 static String card(String s){Matcher m=Pattern.compile("(?:[*•xх]+\\s*)?(\\d{4})$").matcher(norm(s));return m.find()?m.group(1):"";}
 static long amount(String s){String n=norm(s).replaceAll("(?iu)(₽|руб(?:лей|ля|ль)?\\.?|rub|rur)","").trim();if(!n.matches("[+-]?\\s*\\d+(?:[ ]\\d{3})*(?:[.,]\\d{1,2})?"))throw new IllegalArgumentException();long v=BankParser.money(n);if(v<=0||v>10000000000000L)throw new IllegalArgumentException();return v;}

 private static long nonnegativeMoney(String s){String n=norm(s).replaceAll("(?iu)(₽|руб(?:лей|ля|ль)?\\.?|rub|rur)","").trim();if(!n.matches("[+-]?\\s*\\d+(?:[ ]\\d{3})*(?:[.,]\\d{1,2})?"))throw new IllegalArgumentException();long v=BankParser.money(n);if(v<0||v>10000000000000L)throw new IllegalArgumentException();return v;}
 static String kind(String text,String signed){for(String type:new String[]{"expense","income","refund","transfer_out","transfer_in","own","own_out","own_in","cash"})if(norm(text).equals(type))return type;String t=title(text);
  if(t.matches(".*(между своими|перевод себе).*"))return "own";
  if(t.matches(".*(возврат|refund).*"))return "refund";
  if(t.matches(".*(снятие|выдача наличных|cash withdrawal).*"))return "cash";
  if(t.matches(".*(внесение наличных|пополнение наличными|через банкомат|через терминал).*"))return "own_in";
  for(String type:new String[]{"expense","income","refund","transfer_out","transfer_in","own","own_out","own_in","cash"})if(t.equals(type))return type;
  if(t.matches(".*(зачислен|пополнен|поступлен|приход|доход|входящий перевод).*"))return "income";
  if(t.matches(".*(покупк|оплат|списан|расход|исходящий перевод).*"))return t.contains("перевод")?"transfer_out":"expense";
  if(norm(signed).startsWith("-"))return "expense";if(norm(signed).startsWith("+"))return "income";return "unknown";
 }
 static Row row(Entry e,String document,int line,String warning){Row r=new Row();if(e.key.isEmpty())e.key=BankParser.fingerprint("statement|"+e.bank+"|"+document+"|"+line);e.source="statement";e.review=e.type.equals("unknown")||e.category.equals("Другое")||e.type.startsWith("transfer");r.entry=e;r.number=line;r.warning=warning;r.selected=e.counted()&&warning.isEmpty();return r;}

 public static List<List<String>> csvCells(String input,char sep){
  List<List<String>> result=new ArrayList<>();List<String> row=new ArrayList<>();StringBuilder cell=new StringBuilder();boolean quoted=false;
  for(int i=0;i<input.length();i++){char c=input.charAt(i);if(c=='"'){if(quoted&&i+1<input.length()&&input.charAt(i+1)=='"'){cell.append('"');i++;}else quoted=!quoted;}
   else if(!quoted&&(c==sep||c=='\n'||c=='\r')){row.add(cell.toString());cell.setLength(0);if(c!=sep){if(c=='\r'&&i+1<input.length()&&input.charAt(i+1)=='\n')i++;result.add(row);row=new ArrayList<>();}}
   else cell.append(c);
  }
  if(quoted)throw new IllegalArgumentException("Незакрытая кавычка в CSV");if(cell.length()>0||!row.isEmpty()){row.add(cell.toString());result.add(row);}return result;
 }
 public static Result csv(String text,String bank,String doc){
  text=text.replace("\ufeff","");Result out=new Result();List<List<String>> cells=null;int header=-1,date=-1,sum=-1,desc=-1,type=-1,currency=-1,card=-1,debit=-1,credit=-1,status=-1;
  for(char sep:new char[]{';','\t',','}){
   List<List<String>> trial=csvCells(text,sep);
   for(int i=0;i<Math.min(25,trial.size());i++){List<String> h=trial.get(i);int d=col(h,"дата операции","дата","date","дата и время операции");int a=col(h,"сумма платежа","сумма в валюте счета","сумма руб","сумма операции","сумма","amount");int de=col(h,"расход","списание","дебет","debit"),cr=col(h,"приход","зачисление","кредит","credit");
    if(d>=0&&(a>=0||de>=0||cr>=0)){cells=trial;header=i;date=d;sum=a;debit=de;credit=cr;desc=col(h,"описание","назначение платежа","описание операции","магазин","description");type=col(h,"тип","тип операции","вид операции","type");card=col(h,"номер карты","карта","card");status=col(h,"статус","status");currency=col(h,a>=0&&title(h.get(a)).equals("сумма платежа")?"валюта платежа":"валюта операции","валюта счета","валюта","currency");break;}
   }if(cells!=null)break;
  }
  if(cells==null)throw new IllegalArgumentException("Не найдены колонки даты и суммы. Нужен CSV с заголовками или PDF с текстом.");
  for(int i=header+1;i<cells.size();i++){
   List<String> c=cells.get(i);if(c.size()==1&&at(c,0).isEmpty())continue;if(out.rows.size()>=2000)throw new IllegalArgumentException("Не больше 2000 строк за один импорт");
   try{
    String state=title(at(c,status));if(!state.isEmpty()&&!Arrays.asList("ok","успешно","выполнена","выполнено","исполнено","проведена","проведено","success").contains(state)){out.skipped++;continue;}
    Entry e=new Entry();e.bank=bank;e.time=date(at(c,date));e.card=card(at(c,card));e.merchant=at(c,desc);if(e.merchant.isEmpty())e.merchant="Операция из выписки";if(e.merchant.length()>200)e.merchant=e.merchant.substring(0,200);
    String value=at(c,sum),forced="",warning="";
    if(debit>=0||credit>=0){long de=0,cr=0;try{de=amount(at(c,debit));}catch(Exception ignored){}try{cr=amount(at(c,credit));}catch(Exception ignored){}
     if(de>0&&cr>0){warning="Заполнены и расход, и приход";value="";}else if(de>0){value=at(c,debit);forced="expense";}else if(cr>0){value=at(c,credit);forced="income";}
    }
    try{e.amount=amount(value);}catch(Exception ignored){e.amount=0;warning="Проверь сумму";}
    e.type=forced.isEmpty()?kind(at(c,type)+" "+e.merchant,value):forced;
    if(!at(c,type).isEmpty()){String explicit=kind(at(c,type),"");if(!explicit.equals("unknown"))e.type=explicit;}
    String cur=title(at(c,currency));if(currency>=0&&!Arrays.asList("rub","rur","руб","₽").contains(cur)){e.type="unknown";e.amount=0;warning="Валюта не подтверждена как рубли";}
    if(e.type.equals("unknown"))warning=warning.isEmpty()?"Выбери расход или поступление":warning;
    e.category=e.type.startsWith("transfer")||e.ownTransfer()?"Переводы":e.type.equals("cash")?"Наличные":BankParser.category(e.merchant);
    e.raw=String.join(" | ",c);if(e.raw.length()>6000)e.raw=e.raw.substring(0,6000);out.rows.add(row(e,doc,i+1,warning));
   }catch(Exception ex){out.skipped++;}
  }
  out.note="CSV: однозначные строки подготовлены автоматически. Проверка нужна только для строк без направления или с неподтверждённой валютой.";return out;
 }

 /** Entry point for PDF/TXT. Known bank PDFs are parsed deterministically before the conservative fallback. */
 public static Result text(String text,String bank,String doc){
  String low=title(text);
  if("Сбер".equals(bank)&&low.contains("выписка по счёту дебетовой карты")&&low.contains("итого по операциям за период")&&low.contains("остаток средств"))return sberDebit(text,doc);
  if("Т-Банк".equals(bank)&&low.contains("выписка по договору")&&low.contains("операции по карте")&&low.contains("баланс на"))return tbankDebit(text,doc);
  if("Альфа-Банк".equals(bank)&&low.contains("счёт кредитной карты")&&low.contains("общая задолженность к погашению")&&low.contains("операции по счету"))return alfaCredit(text,doc);
  return genericText(text,bank,doc);
 }


 static final Pattern TBANK_ROW=Pattern.compile("^\\s*(\\d{2}\\.\\d{2}\\.\\d{2})(?:\\s+(\\d{2}:\\d{2}))?\\s+(\\d{2}\\.\\d{2}\\.\\d{2})\\s+(.+?)\\s+([+−–-]?\\s*(?:\\d{1,3}(?:[ \\u00a0\\u202f]\\d{3})+|\\d+)\\.\\d{2})\\s*₽\\s+([+−–-]?\\s*(?:\\d{1,3}(?:[ \\u00a0\\u202f]\\d{3})+|\\d+)\\.\\d{2})\\s*₽\\s*$",Pattern.UNICODE_CASE);
 static final Pattern ALFA_ROW=Pattern.compile("^\\s*(\\d{2}\\.\\d{2}\\.\\d{4})\\s+(\\S+)\\s+(.+?)\\s+([+−–-]?\\s*(?:\\d{1,3}(?:[ \\u00a0\\u202f]\\d{3})+|\\d+),\\d{2})\\s+RUR\\s*$",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE);

 static long shortDate(String d,String time){
  String[] p=d.split("\\.");LocalDate day=LocalDate.of(2000+Integer.parseInt(p[2]),Integer.parseInt(p[1]),Integer.parseInt(p[0]));
  LocalTime t=time==null||time.isEmpty()?LocalTime.NOON:LocalTime.parse(time);return day.atTime(t).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
 }
 static long signedMoney(String s){String n=norm(s);boolean neg=n.startsWith("-");long v=BankParser.money(n);return neg?-v:v;}
 static String cleanTbankMerchant(String d){
  String x=norm(d).replaceFirst("(?iu)^Оплата\\s+(?:в|услуг)\\s+","").replaceFirst("(?iu)^Отмена операции оплаты\\s+","").replaceAll("\\s+"," ").trim();
  return x.length()>200?x.substring(0,200):x;
 }
 static String tbankKind(String desc,String amount){
  String d=title(desc);boolean plus=norm(amount).startsWith("+");
  if(d.contains("кэшбэк"))return "income";
  if(d.contains("отмена операции оплаты")||d.contains("возврат"))return "refund";
  if(d.matches("(?s).*(пополнение наличными|внесение наличных|через терминал|через банкомат).*") )return "own_in";
  if(d.contains("перевод себе")||d.contains("перевод с договора"))return plus?"own_in":"own_out";
  if(d.contains("внутренний перевод"))return plus?"own_in":"own_out";
  if(d.contains("внешний перевод"))return plus?"transfer_in":"transfer_out";
  if(d.contains("снятие наличных"))return "cash";
  if(d.contains("внесение наличных")||d.contains("пополнение наличными")||d.contains("пополнение через банкомат")||d.contains("пополнение через терминал"))return "own_in";
  if(d.startsWith("оплата"))return "expense";
  return plus?"income":"expense";
 }
 static String tbankCategory(String desc,String type){
  if(type.startsWith("own")||type.startsWith("transfer"))return "Переводы";
  if(type.equals("cash"))return "Наличные";
  if(type.equals("income"))return "Доходы";
  return BankParser.category(cleanTbankMerchant(desc));
 }
 private static Result tbankDebit(String input,String doc){
  Result out=new Result();out.verificationMethod="summary";String text=input.replace('\u00a0',' ').replace('\u202f',' ');String flat=text.replaceAll("[\\t ]+"," ");
  List<Long> balances=new ArrayList<>();List<String> balanceDates=new ArrayList<>();
  Matcher bm=Pattern.compile("Баланс на\\s+(\\d{2}\\.\\d{2}\\.\\d{2})\\s+(\\d+(?: \\d{3})*\\.\\d{2})\\s*₽",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);
  while(bm.find())try{balanceDates.add(bm.group(1));balances.add(amount(bm.group(2)));}catch(Exception ignored){}
  Matcher cr=Pattern.compile("Поступления\\s+(\\d+(?: \\d{3})*\\.\\d{2})\\s*₽",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);
  Matcher dr=Pattern.compile("Расходы\\s*-?\\s*(\\d+(?: \\d{3})*\\.\\d{2})\\s*₽",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);
  Matcher cb=Pattern.compile("Кэшбэк\\s+(\\d+(?: \\d{3})*\\.\\d{2})\\s*₽",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);
  long credits=cr.find()?amount(cr.group(1)):0,netExpenses=dr.find()?amount(dr.group(1)):0,cashback=cb.find()?amount(cb.group(1)):0;
  if(balances.size()>=2){out.openingBalance=balances.get(0);out.closingBalance=balances.get(balances.size()-1);out.periodFrom=balanceDates.get(0);out.periodTo=balanceDates.get(balanceDates.size()-1);out.hasSummary=true;}
  String[] lines=text.split("\\r?\\n");String currentCard="";LinkedHashSet<String> cards=new LinkedHashSet<>();Map<String,Long> statedCardExpenses=new LinkedHashMap<>(),parsedCardNet=new LinkedHashMap<>();Map<String,Integer> occurrences=new HashMap<>();int lineNo=0;
  for(String source:lines){lineNo++;String line=source.trim();if(line.isEmpty())continue;
   Matcher ch=Pattern.compile("Операции по карте №\\s*\\d*[*•xх]+(\\d{4})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(line);
   if(ch.find()){currentCard=ch.group(1);cards.add(currentCard);continue;}
   if(!currentCard.isEmpty()){Matcher ce=Pattern.compile("^Расходы:\\s*(\\d+(?: \\d{3})*\\.\\d{2})\\s*₽",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(line);if(ce.find()){try{statedCardExpenses.put(currentCard,amount(ce.group(1)));}catch(Exception ignored){}continue;}}
   Matcher m=TBANK_ROW.matcher(line);if(!m.matches()||currentCard.isEmpty())continue;
   try{
    String opDate=m.group(1),opTime=m.group(2)==null?"":m.group(2),processDate=m.group(3),desc=norm(m.group(4)),value=norm(m.group(5));
    long a=amount(value);String type=tbankKind(desc,value);Entry e=new Entry();e.bank="Т-Банк";e.card=currentCard;e.time=shortDate(opDate,opTime);e.processedTime=shortDate(processDate,"");e.amount=a;e.type=type;e.merchant=cleanTbankMerchant(desc);if(e.merchant.isEmpty())e.merchant=BankParser.defaultTitle(type);if(type.equals("own_in")&&title(desc).matches(".*(внесение наличных|пополнение наличными|через банкомат|через терминал).*"))e.counterparty="Наличные";if(type.equals("cash"))e.counterparty="Наличные";e.category=tbankCategory(desc,type);e.raw=line;e.review=false;
    String base="statement|tbank|"+e.card+"|"+opDate+"|"+opTime+"|"+processDate+"|"+a+"|"+type+"|"+title(e.merchant);int n=occurrences.getOrDefault(base,0)+1;occurrences.put(base,n);e.key=BankParser.fingerprint(base+"|"+n);
    Row r=row(e,doc,lineNo,"");r.entry.review=false;r.selected=true;out.rows.add(r);
    if(e.direction()>0)out.parsedCredits+=a;else if(e.direction()<0)out.parsedDebits+=a;
    long net=parsedCardNet.getOrDefault(currentCard,0L);if(e.direction()<0)net+=a;else if(type.equals("refund"))net-=a;parsedCardNet.put(currentCard,net);
   }catch(Exception ex){out.skipped++;}
  }
  long refunds=0;for(Row r:out.rows)if(r.entry.type.equals("refund"))refunds+=r.entry.amount;
  out.totalCredits=credits+cashback+refunds;out.totalDebits=netExpenses+refunds;
  boolean cardsOk=!cards.isEmpty();for(String c:cards)if(statedCardExpenses.containsKey(c)&&!Objects.equals(statedCardExpenses.get(c),parsedCardNet.getOrDefault(c,Long.MIN_VALUE)))cardsOk=false;
  long expected=out.openingBalance+out.totalCredits-out.totalDebits;out.verified=out.hasSummary&&!out.rows.isEmpty()&&out.parsedCredits==out.totalCredits&&out.parsedDebits==out.totalDebits&&expected==out.closingBalance&&cardsOk;
  out.cardsSummary=String.join(", ",cards);out.accountCard="";
  if(out.verified){out.validation="Сводка Т-Банка и расходы по "+cards.size()+" картам совпали.";out.note="Т-Банк/PDF: операции двух карт разделены автоматически, одинаковые суммы в двух денежных колонках считаются одной операцией. Подтверждать каждую строку не нужно.";}
  else{out.validation="Контроль Т-Банка не сошёлся: поступления "+out.parsedCredits+" коп., списания "+out.parsedDebits+" коп.";out.note="Т-Банк/PDF распознан, но контрольные суммы не совпали. Массовый автоимпорт отключён.";for(Row r:out.rows)r.selected=false;}
  return out;
 }

 private static final class AlfaPending{String date,code,desc,amount;int line;}
 private static boolean ignoreAlfaContinuation(String line){
  String t=title(line);return t.startsWith("страница ")||t.startsWith("а.а. панченко")||t.startsWith("уполномоченное лицо")||t.startsWith("(подпись сотрудника")||t.startsWith("(ф.и.о. сотрудника")||t.startsWith("дата проводки")||t.startsWith("в валюте счета")||t.startsWith("hold")||t.startsWith("неподтвержденная операция");
 }
 private static Result alfaCredit(String input,String doc){
  Result out=new Result();out.creditStatement=true;out.verificationMethod="credit-summary";String text=input.replace('\u00a0',' ').replace('\u202f',' ');String flat=text.replaceAll("[\\t ]+"," ");
  Matcher period=Pattern.compile("За период с\\s+(\\d{2}\\.\\d{2}\\.\\d{4})\\s+по\\s+(\\d{2}\\.\\d{2}\\.\\d{4})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);if(period.find()){out.periodFrom=period.group(1);out.periodTo=period.group(2);}
  Matcher account=Pattern.compile("Номер счета\\s+([0-9 ]{15,30})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);if(account.find())out.accountNumber=account.group(1).replaceAll("\\s+","");
  out.openingBalance=findSignedAlfa(flat,"Входящий остаток");
  long summaryCredits=findPositiveAlfa(flat,"Поступления"),summaryExpenses=findPositiveAlfa(flat,"Расходы");out.closingBalance=findSignedAlfa(flat,"Исходящий остаток");
  out.pendingAmount=findPositiveAlfa(flat,"Неподтвержденные операции");out.availableCredit=findPositiveAlfa(flat,"Текущий баланс");out.creditDebt=findPositiveAlfa(flat,"Общая задолженность к погашению");out.creditLimit=out.availableCredit+out.creditDebt;
  Matcher card=Pattern.compile("Операция по карте:\\s*\\d+\\+{2,}(\\d{4})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(text);if(card.find())out.accountCard=card.group(1);
  Matcher holds=Pattern.compile("Неподтвержденная операция:.*?(-\\s*(?:\\d{1,3}(?: \\d{3})+|\\d+),\\d{2})\\s+RUR",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(text);long parsedPending=0;while(holds.find())try{parsedPending+=Math.abs(signedMoney(holds.group(1)));}catch(Exception ignored){}
  String[] lines=text.split("\\r?\\n");AlfaPending pending=null;long postedCredits=0,postedDebits=0;int lineNo=0;
  for(String source:lines){lineNo++;String line=source.trim();if(line.isEmpty())continue;Matcher m=ALFA_ROW.matcher(line);
   if(m.matches()){if(pending!=null){long[] sums=flushAlfa(out,pending,doc);postedCredits+=sums[0];postedDebits+=sums[1];}pending=new AlfaPending();pending.date=m.group(1);pending.code=m.group(2);pending.desc=norm(m.group(3));pending.amount=norm(m.group(4));pending.line=lineNo;continue;}
   if(pending!=null&&!ignoreAlfaContinuation(line)&&!line.contains("Неподтвержденная операция:"))pending.desc=(pending.desc+" "+norm(line)).replaceAll("\\s+"," ").trim();
   if(line.contains("Неподтвержденная операция:")&&pending!=null){long[] sums=flushAlfa(out,pending,doc);postedCredits+=sums[0];postedDebits+=sums[1];pending=null;}
  }
  if(pending!=null){long[] sums=flushAlfa(out,pending,doc);postedCredits+=sums[0];postedDebits+=sums[1];}
  out.parsedCredits=postedCredits;out.parsedDebits=postedDebits;out.totalCredits=summaryCredits;out.totalDebits=summaryExpenses;
  boolean pendingOk=out.pendingAmount==0||parsedPending==out.pendingAmount;boolean math=out.openingBalance+summaryCredits-summaryExpenses==out.closingBalance;boolean postedOk=postedCredits==summaryCredits&&postedDebits+out.pendingAmount==summaryExpenses;
  out.hasSummary=summaryCredits>0&&summaryExpenses>0&&out.creditDebt>=0&&out.availableCredit>=0;out.verified=out.hasSummary&&postedOk&&math&&pendingOk&&!out.rows.isEmpty();
  if(out.verified){out.validation="Альфа: проводки совпали со сводкой, неподтверждённые операции сверены отдельно. Технические движения кредита скрыты.";out.note="Альфа-Банк/PDF: реальные покупки, платежи, комиссии, проценты, возвраты и погашения отделены от служебных проводок «Предоставление транша»/«Погашение ОД». Долг синхронизируется по банковской сводке.";}
  else{out.validation="Контроль Альфа-Банка не сошёлся: проводки + неподтверждённые операции отличаются от сводки.";out.note="Альфа-Банк/PDF распознан, но автоматический импорт отключён до сверки.";for(Row r:out.rows)r.selected=false;}
  return out;
 }
 private static long findPositiveAlfa(String flat,String label){Matcher m=Pattern.compile(Pattern.quote(label)+"\\s+(\\d+(?: \\d{3})*,\\d{2})\\s*RUR",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);if(!m.find())return 0;try{return amount(m.group(1));}catch(Exception ex){return 0;}}
 private static long findSignedAlfa(String flat,String label){Matcher m=Pattern.compile(Pattern.quote(label)+"\\s+([+−–-]?\\s*\\d+(?: \\d{3})*,\\d{2})\\s*RUR",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);if(!m.find())return 0;try{return signedMoney(m.group(1));}catch(Exception ex){return 0;}}
 private static long[] flushAlfa(Result out,AlfaPending p,String doc){
  long signed;try{signed=signedMoney(p.amount);}catch(Exception ex){out.skipped++;return new long[]{0,0};}
  long credits=signed>0?signed:0,debits=signed<0?-signed:0;String low=title(p.desc),code=p.code.toUpperCase(Locale.ROOT);
  if(low.contains("предоставление транша")||low.contains("погашение од")||low.contains("несанкционированный перерасход")||code.startsWith("WIRR"))return new long[]{credits,debits};
  Entry e=new Entry();e.bank="Альфа-Банк";e.card=out.accountCard;e.time=date(p.date);e.processedTime=e.time;e.authCode=p.code;e.amount=Math.abs(signed);e.raw=p.date+" | "+p.code+" | "+p.desc+" | "+p.amount+" RUR";if(e.raw.length()>6000)e.raw=e.raw.substring(0,6000);e.review=false;
  if(low.contains("погашение процентов")){e.type="expense";e.merchant="Проценты по кредитной карте";e.category="Кредиты";}
  else if(code.startsWith("CRD_")){String od=extractAlfaOperationDate(p.desc);if(!od.isEmpty())e.time=shortDate(od,"");String ec=extractAlfaCard(p.desc);if(!ec.isEmpty())e.card=ec;e.merchant=extractAlfaMerchant(p.desc);if(e.merchant.isEmpty())e.merchant="Операция по карте";if(signed>0)e.type="refund";else if(low.contains("mcc6011")||low.contains("\\atm "))e.type="cash";else e.type="expense";e.category=e.type.equals("cash")?"Наличные":alfaMccCategory(p.desc,e.merchant);}
  else if(code.startsWith("F")){e.type=signed<0?"expense":"income";e.merchant=low.contains("обслуживание карты")?"Обслуживание кредитной карты":"Комиссия Альфа-Банка";e.category="Комиссии";}
  else if(code.startsWith("MPL")){e.type="income";e.merchant="Кэшбэк Альфа-Банка";e.category="Доходы";}
  else if(code.startsWith("A")){e.type=signed<0?"expense":"income";e.merchant=extractAfter(p.desc,"в пользу");e.category=BankParser.category(e.merchant);}
  else if(code.startsWith("C")){
   if(signed<0){e.type="expense";e.merchant=cleanAlfaPayment(p.desc);e.category=BankParser.category(e.merchant);}
   else{e.type="own_in";e.merchant="Погашение кредитной карты";e.category="Кредиты";e.counterparty=counterparty(p.desc);}
  }else return new long[]{credits,debits};
  if(e.merchant==null||e.merchant.isEmpty())e.merchant=BankParser.defaultTitle(e.type);
  String identity="statement|alfa|"+p.code+"|"+p.date+"|"+e.amount+"|"+e.type+"|"+e.card;e.key=BankParser.fingerprint(identity);
  Row r=row(e,doc,p.line,"");r.entry.review=false;r.selected=true;out.rows.add(r);return new long[]{credits,debits};
 }
 private static String extractAlfaCard(String s){Matcher m=Pattern.compile("Операция по карте:\\s*\\d+\\+{2,}(\\d{4})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(s);return m.find()?m.group(1):"";}
 private static String extractAlfaOperationDate(String s){Matcher m=Pattern.compile("дата совершения операции:\\s*(\\d{2}\\.\\d{2}\\.\\d{2})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(s);return m.find()?m.group(1):"";}
 private static String extractAlfaMerchant(String s){
  Matcher m=Pattern.compile("место совершения операции:\\s*(.+?)\\s+MCC\\d+",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(s);if(!m.find())return "";
  String place=norm(m.group(1));String[] parts=place.split("\\\\");String merchant=parts.length>=4?parts[parts.length-1]:place;return merchant.length()>200?merchant.substring(0,200):merchant;
 }
 private static String extractAfter(String s,String token){String low=title(s);int i=low.indexOf(token);if(i<0)return norm(s);String x=norm(s.substring(Math.min(s.length(),i+token.length()))).replaceAll("\\s+"," ");return x.length()>200?x.substring(0,200):x;}
 private static String cleanAlfaPayment(String s){String x=norm(s).replaceFirst("(?iu)^Платеж\\s+\\S+\\s+","");Matcher recipient=Pattern.compile("(?iu)Получатель\\s+(.+)$").matcher(x);if(recipient.find())x=recipient.group(1);else{x=x.replaceFirst("(?iu)^в\\s+","").replaceFirst("(?iu)^пользу\\s+","").replaceFirst("(?iu)\\s+через Систему быстрых платежей.*$","");}x=x.replaceAll("\\s+"," ").trim();return x.length()>200?x.substring(0,200):x;}
 private static String alfaMccCategory(String s,String merchant){Matcher m=Pattern.compile("(?iu)MCC(\\d{3,4})").matcher(s);if(m.find()){String c=m.group(1);if(c.equals("5411"))return "Продукты";if(c.equals("5912")||c.equals("8011")||c.equals("8062")||c.equals("8071")||c.equals("742"))return "Здоровье";if(c.equals("4121")||c.equals("4131")||c.equals("5541")||c.equals("5542"))return "Транспорт";if(c.equals("5812")||c.equals("5813")||c.equals("5814")||c.equals("5462"))return "Кафе";if(c.equals("5815"))return "Подписки";if(c.equals("7995"))return "Развлечения";if(c.equals("6011"))return "Наличные";if(c.equals("5331")||c.equals("5992")||c.equals("5964"))return "Покупки";}return BankParser.category(merchant);}

 private static final class SberPending{String opDate,time,category,amount,balance,processDate,auth="",description="";int line;}
 private static Result sberDebit(String input,String doc){
  Result out=new Result();out.verificationMethod="sber-chain";String text=input.replace('\u00a0',' ').replace('\u202f',' ');String flat=text.replaceAll("[\\t ]+"," ");
  Matcher period=Pattern.compile("За период\\s+(\\d{2}\\.\\d{2}\\.\\d{4})\\s+[—-]\\s+(\\d{2}\\.\\d{2}\\.\\d{4})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);if(period.find()){out.periodFrom=period.group(1);out.periodTo=period.group(2);}
  Matcher account=Pattern.compile("Номер сч[её]та\\s+([0-9 ]{15,30})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);if(account.find())out.accountNumber=account.group(1).replaceAll("\\s+","");
  Matcher cm=Pattern.compile("Карта\\s+[^\\n\\r]*?[•*]{2,}\\s*(\\d{4})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(text);if(cm.find())out.accountCard=cm.group(1);
  List<Long> balances=new ArrayList<>();Matcher bm=Pattern.compile("Остаток на\\s+\\d{2}\\.\\d{2}\\.\\d{4}\\s+(\\d+(?: \\d{3})*,\\d{2})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);while(bm.find())try{balances.add(nonnegativeMoney(bm.group(1)));}catch(Exception ignored){}
  Matcher cr=Pattern.compile("Пополнение\\s+(\\d+(?: \\d{3})*,\\d{2})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);Matcher dr=Pattern.compile("Списание\\s+(\\d+(?: \\d{3})*,\\d{2})",Pattern.CASE_INSENSITIVE|Pattern.UNICODE_CASE).matcher(flat);
  if(balances.size()>=2&&cr.find()&&dr.find())try{out.openingBalance=balances.get(0);out.closingBalance=balances.get(balances.size()-1);out.totalCredits=amount(cr.group(1));out.totalDebits=amount(dr.group(1));out.hasSummary=true;}catch(Exception ignored){}

  String[] lines=text.split("\\r?\\n");SberPending pending=null;int lineNo=0;
  for(String sourceLine:lines){lineNo++;String line=sourceLine.replace('\u00a0',' ').replace('\u202f',' ').trim();if(line.isEmpty())continue;
   Matcher primary=SBER_PRIMARY.matcher(line);
   if(primary.matches()){
    if(pending!=null)flushSber(out,pending,doc);
    pending=new SberPending();pending.opDate=primary.group(1);pending.time=primary.group(2);pending.category=norm(primary.group(3));pending.amount=norm(primary.group(4));pending.balance=norm(primary.group(5));pending.line=lineNo;continue;
   }
   if(pending==null)continue;
   Matcher process=SBER_PROCESS.matcher(line);
   if(process.matches()){
    pending.processDate=process.group(1);pending.auth=process.group(2);pending.description=norm(process.group(3));continue;
   }
   if(!pending.auth.isEmpty()){
    if(line.matches("(?iu)^В сумму операции включена комиссия.*")){pending.description=(pending.description+" "+line).trim();continue;}
    if(!pending.description.matches("(?s).*[*•]{2,}\\d{4}.*")&&!ignoreSberLine(line))pending.description=(pending.description+" "+line).replaceAll("\\s+"," ").trim();
   }
  }
  if(pending!=null)flushSber(out,pending,doc);
  for(Row r:out.rows){if(r.entry.direction()>0)out.parsedCredits+=r.entry.amount;else if(r.entry.direction()<0)out.parsedDebits+=r.entry.amount;}
  long expectedClose=out.hasSummary?out.openingBalance+out.totalCredits-out.totalDebits:Long.MIN_VALUE;
  verifySberBalanceChain(out);
  out.verified=out.hasSummary&&!out.rows.isEmpty()&&out.parsedCredits==out.totalCredits&&out.parsedDebits==out.totalDebits&&expectedClose==out.closingBalance&&out.balanceChainVerified;
  if(out.verified){out.validation="Итоги и цепочка остатков совпали: "+out.rows.size()+" операций проверены по банковским остаткам.";out.note="Сбер/PDF: выписка распознана и математически проверена. Операции выбраны автоматически; подтверждать каждую строку не нужно.";}
  else{out.validation="Контроль выписки не сошёлся: поступления "+out.parsedCredits+" коп., списания "+out.parsedDebits+" коп., разрывов цепочки остатков: "+out.balanceChainBreaks+".";out.note="Сбер/PDF распознан, но контрольные итоги или цепочка остатков не совпали. Автоматический импорт целиком отключён до проверки.";for(Row r:out.rows)r.selected=false;}
  return out;
 }

 private static void verifySberBalanceChain(Result out){
  out.balanceChainBreaks=0;out.balanceChainVerified=false;if(!out.hasSummary||out.rows.isEmpty())return;
  Entry newest=out.rows.get(0).entry,oldest=out.rows.get(out.rows.size()-1).entry;
  if(newest.balanceAfter==Long.MIN_VALUE||newest.balanceAfter!=out.closingBalance)out.balanceChainBreaks++;
  for(int i=0;i+1<out.rows.size();i++){
   Entry current=out.rows.get(i).entry,older=out.rows.get(i+1).entry;
   if(current.balanceAfter==Long.MIN_VALUE||older.balanceAfter==Long.MIN_VALUE||current.direction()==0){out.balanceChainBreaks++;continue;}
   long expected=older.balanceAfter+(long)current.direction()*current.amount;if(expected!=current.balanceAfter)out.balanceChainBreaks++;
  }
  if(oldest.balanceAfter==Long.MIN_VALUE||oldest.direction()==0||out.openingBalance+(long)oldest.direction()*oldest.amount!=oldest.balanceAfter)out.balanceChainBreaks++;
  out.balanceChainVerified=out.balanceChainBreaks==0;
 }

 private static boolean ignoreSberLine(String line){String t=title(line);return t.startsWith("выписка по счёту")||t.startsWith("страница ")||t.startsWith("дата операции")||t.startsWith("дата обработки")||t.startsWith("описание операции")||t.startsWith("и код авторизации")||t.startsWith("сумма в валюте")||t.startsWith("остаток средств")||t.startsWith("в валюте счёта")||t.startsWith("продолжение на следующей")||t.startsWith("для проверки подлинности")||t.startsWith("действителен")||t.startsWith("до 24.")||t.startsWith("1. зайдите")||t.startsWith("2. нажмите")||t.startsWith("3. получите")||t.startsWith("* предоставляя")||t.startsWith("900 ")||t.startsWith("ул. вавилова");}
 private static void flushSber(Result out,SberPending p,String doc){
  if(p.auth.isEmpty()||p.description.isEmpty()){out.skipped++;return;}
  try{
   Entry e=new Entry();e.bank="Сбер";e.time=date(p.opDate+" "+p.time);e.processedTime=date(p.processDate);e.authCode=p.auth;e.amount=amount(p.amount);e.balanceAfter=nonnegativeMoney(p.balance);e.card=extractCard(p.description);if(e.card.isEmpty())e.card=out.accountCard;e.bankCategory=p.category;e.raw=(p.opDate+" "+p.time+" | "+p.category+" | "+p.amount+" | остаток "+p.balance+" | "+p.processDate+" "+p.auth+" | "+p.description);if(e.raw.length()>6000)e.raw=e.raw.substring(0,6000);
   boolean plus=norm(p.amount).startsWith("+");String desc=cleanSberDescription(p.description);e.merchant=desc.isEmpty()?p.category:desc;e.counterparty=counterparty(desc);e.type=sberKind(p.category,desc,plus);if(title(p.category).contains("внесение наличных"))e.counterparty="Наличные";if(e.type.equals("own_in")&&title(p.category+" "+desc).matches(".*(внесение наличных|через банкомат|через терминал).*"))e.counterparty="Наличные";if(e.type.equals("cash"))e.counterparty="Наличные";e.category=sberCategory(p.category,desc,e.type);e.review=false;
   String identity="statement|sber|"+e.card+"|"+e.authCode+"|"+p.processDate+"|"+e.amount+"|"+e.type;e.key=BankParser.fingerprint(identity);
   Row r=row(e,doc,p.line,"");r.entry.review=false;r.selected=true;out.rows.add(r);
  }catch(Exception ex){out.skipped++;}
 }
 private static String extractCard(String s){Matcher m=Pattern.compile("[*•]{2,}\\s*(\\d{4})(?!\\d)").matcher(s);return m.find()?m.group(1):"";}
 private static String cleanSberDescription(String d){String s=norm(d).replaceAll("(?iu)\\.?\\s*Операция по(?:\\s+карте)?\\s*[*•]{2,}\\d{4}\\.?","").replaceAll("(?iu)\\s*В сумму операции включена комиссия.*$","").replaceAll("\\s+"," ").trim();return s.length()>200?s.substring(0,200):s;}
 private static String counterparty(String desc){String d=norm(desc);if(d.matches("(?iu).*T-Bank.*|.*Т-Банк.*|.*Тинькофф.*"))return "Т-Банк";if(d.matches("(?iu).*Альфа[- ]?банк.*"))return "Альфа-Банк";if(d.matches("(?iu).*Ozon Bank.*"))return "Ozon Bank";return "";}
 private static String sberKind(String category,String desc,boolean plus){String c=title(category),d=title(desc);
  if(c.contains("возврат")||d.contains("возврат"))return "refund";
  if(c.contains("выдача наличных")||d.contains("выдача наличных"))return "cash";
  if(c.contains("внесение наличных")||d.contains("внесение наличных")||d.contains("через банкомат")||d.contains("через терминал"))return "own_in";
  if(d.contains("заработная плата")||d.contains("премия, иные поощрительные выплаты"))return "income";
  boolean ownBank=d.contains("t-bank")||d.contains("т-банк")||d.contains("тинькофф")||d.contains("альфа-банк")||d.contains("альфа банк");
  boolean selfName=d.contains("к. андрей дмитриевич");
  if(d.contains("branch karta-credit"))return "own_out";
  if(ownBank||selfName)return plus?"own_in":"own_out";
  if(c.contains("перевод")||d.startsWith("перевод ")||d.contains(" перевод "))return plus?"transfer_in":"transfer_out";
  if(plus)return "income";
  return "expense";
 }
 private static String sberCategory(String category,String desc,String type){String c=title(category),d=title(desc);if(type.startsWith("own")||type.startsWith("transfer"))return d.contains("karta-credit")||d.contains("альфа")?"Кредиты":"Переводы";if(type.equals("cash")||c.contains("внесение наличных"))return "Наличные";if(d.contains("mobile bank: komissiya"))return "Комиссии";if(type.equals("income")||type.equals("refund"))return type.equals("refund")?BankParser.category(desc):"Доходы";if(c.contains("супермаркет"))return "Продукты";if(c.contains("ресторан")||c.contains("кафе"))return "Кафе";if(c.contains("транспорт"))return "Транспорт";if(c.contains("здоровье"))return "Здоровье";if(c.contains("одежда")||c.contains("аксессуар"))return "Покупки";if(c.contains("отдых")||c.contains("развлеч"))return "Развлечения";String guessed=BankParser.category(desc);return guessed.equals("Другое")?"Другое":guessed;}

 private static Result genericText(String text,String bank,String doc){
  Result out=new Result();String[] lines=text.replace('\u00a0',' ').split("\\r?\\n");int index=0;
  for(String line:lines){index++;String raw=norm(line);Matcher d=DATE.matcher(raw);if(!d.find()){continue;}
   if(out.rows.size()>=2000)throw new IllegalArgumentException("Не больше 2000 строк за импорт");
   try{
    long time=date(d.group());String rest=raw.substring(d.end()).trim();Matcher second=DATE.matcher(rest);if(second.lookingAt())rest=rest.substring(second.end()).trim();
    if(rest.toLowerCase(new Locale("ru")).matches(".*(остаток|баланс|итого|задолженность|лимит).*")){out.skipped++;continue;}
    Entry e=new Entry();e.bank=bank;e.time=time;e.raw=raw.length()>6000?raw.substring(0,6000):raw;
    Matcher money=SIGNED_RUB.matcher(rest);String value="";int a=-1,b=-1,count=0;
    while(money.find()){count++;if(count==1){value=money.group(1);a=money.start();b=money.end();}}
    if(count==0){money=MONEY.matcher(rest);while(money.find()){count++;if(count==1){value=money.group(1);a=money.start();b=money.end();}}}
    if(count==0){out.skipped++;continue;}
    String warning=count>1?"Несколько сумм в строке — укажи сумму операции":"";
    e.amount=count==1?amount(value):0;e.type=kind(rest,value);
    if(Pattern.compile("(?iu)(usd|eur|cny|kzt|[$€¥])").matcher(rest).find()){e.amount=0;e.type="unknown";warning="Валютная операция требует ручной проверки";}
    e.merchant=norm(a<0?rest:rest.substring(0,a)+" "+rest.substring(b)).replaceAll("\\s+"," ");
    Matcher card=Pattern.compile("[*•]+\\s*(\\d{4})(?!\\d)").matcher(e.merchant);if(card.find())e.card=card.group(1);
    if(e.merchant.length()>200)e.merchant=e.merchant.substring(0,200);if(e.merchant.isEmpty())e.merchant="Операция из выписки";
    e.category=BankParser.category(e.merchant);e.review=true;
    if(e.type.equals("unknown"))warning=warning.isEmpty()?"Выбери вид операции":warning;
    Row r=row(e,doc,index,warning);r.entry.review=true;r.selected=false;out.rows.add(r);
   }catch(Exception ex){out.skipped++;}
  }
  out.note="Текст/PDF неизвестного формата: автоматическая запись отключена для неоднозначных строк. Если банк поддержан отдельным парсером, используй его оригинальную выписку.";return out;
 }
 public static void match(Result result,List<Entry> existing){Set<String> keys=new HashSet<>();for(Entry e:existing)keys.add(e.key);for(Row row:result.rows){row.exact=keys.contains(row.entry.key);row.possible=!row.exact&&possible(row.entry,existing);if(row.exact||row.possible)row.selected=false;}}
 public static boolean possible(Entry a,List<Entry> existing){if(a.amount<=0)return false;for(Entry b:existing){if(!a.bank.equals(b.bank)||a.amount!=b.amount)continue;if(!a.card.isEmpty()&&!b.card.isEmpty()&&!a.card.equals(b.card))continue;if(!compatibleKind(a.type,b.type))continue;long millis=Math.abs(a.time-b.time);String am=merchantKey(a.merchant),bm=merchantKey(b.merchant);boolean similar=!am.isEmpty()&&!bm.isEmpty()&&(am.equals(bm)||am.contains(bm)||bm.contains(am));if(similar&&millis<=4L*86400000L)return true;if((am.isEmpty()||bm.isEmpty())&&millis<=10L*60000L)return true;if(millis<=2L*60000L)return true;}return false;}
 private static boolean compatibleKind(String a,String b){if(a.equals(b))return true;if(a.equals("unknown")||b.equals("unknown"))return true;if((a.equals("own_out")&&b.equals("transfer_out"))||(b.equals("own_out")&&a.equals("transfer_out")))return true;if((a.equals("own_in")&&b.equals("transfer_in"))||(b.equals("own_in")&&a.equals("transfer_in")))return true;return false;}
 private static String merchantKey(String s){return title(s).replaceAll("[^a-zа-я0-9]+","").replaceAll("(rus|novosibirsk|moscow)$","");}
}
