package ru.kazna.app;
import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public final class Store extends SQLiteOpenHelper{
 private static Store instance;private volatile long revision;
 public static synchronized Store get(Context c){if(instance==null)instance=new Store(c.getApplicationContext());return instance;}
 private Store(Context c){super(c,"kazna.db",null,5);}
 public long revision(){return revision;}

 public static final class Account{
  public long id,balance,creditLimit,debt,updatedAt;public boolean hasBalance;
  public String bank="",card="",name="",kind="debit",source="manual";
 }
 public static final class Debt{
  public long id,limitOrPrincipal,debt,monthlyPayment,nextPayment,principalDebt,interestDebt,paymentPrincipal,paymentInterest,maturityDate;public int rateBps,termMonths,remainingMonths;
  public String bank="",name="",kind="credit_card",repaymentAccounts="";
 }

 public void onCreate(SQLiteDatabase db){
  db.execSQL("CREATE TABLE entries (id INTEGER PRIMARY KEY AUTOINCREMENT,fingerprint TEXT UNIQUE NOT NULL,time INTEGER NOT NULL,amount INTEGER NOT NULL,bank TEXT NOT NULL,card TEXT NOT NULL,merchant TEXT NOT NULL,category TEXT NOT NULL,kind TEXT NOT NULL,raw TEXT NOT NULL,source TEXT NOT NULL,review INTEGER NOT NULL,balance_after INTEGER,processed_time INTEGER NOT NULL DEFAULT 0,auth_code TEXT NOT NULL DEFAULT '',counterparty TEXT NOT NULL DEFAULT '',bank_category TEXT NOT NULL DEFAULT '')");
  db.execSQL("CREATE INDEX by_time ON entries(time)");db.execSQL("CREATE TABLE deleted(fingerprint TEXT PRIMARY KEY)");db.execSQL("CREATE TABLE rules(bank TEXT,merchant TEXT,category TEXT,PRIMARY KEY(bank,merchant))");
  createFinancialTables(db);
 }
 private void createFinancialTables(SQLiteDatabase db){
  db.execSQL("CREATE TABLE IF NOT EXISTS accounts (id INTEGER PRIMARY KEY AUTOINCREMENT,bank TEXT NOT NULL,card TEXT NOT NULL DEFAULT '',name TEXT NOT NULL DEFAULT '',kind TEXT NOT NULL DEFAULT 'debit',balance INTEGER NOT NULL DEFAULT 0,has_balance INTEGER NOT NULL DEFAULT 0,credit_limit INTEGER NOT NULL DEFAULT 0,debt INTEGER NOT NULL DEFAULT 0,updated_at INTEGER NOT NULL DEFAULT 0,source TEXT NOT NULL DEFAULT 'manual',UNIQUE(bank,card))");
  db.execSQL("CREATE TABLE IF NOT EXISTS debts (id INTEGER PRIMARY KEY AUTOINCREMENT,bank TEXT NOT NULL DEFAULT '',name TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'credit_card',limit_or_principal INTEGER NOT NULL DEFAULT 0,debt INTEGER NOT NULL DEFAULT 0,monthly_payment INTEGER NOT NULL DEFAULT 0,rate_bps INTEGER NOT NULL DEFAULT 0,next_payment INTEGER NOT NULL DEFAULT 0,principal_debt INTEGER NOT NULL DEFAULT 0,interest_debt INTEGER NOT NULL DEFAULT 0,payment_principal INTEGER NOT NULL DEFAULT 0,payment_interest INTEGER NOT NULL DEFAULT 0,repayment_accounts TEXT NOT NULL DEFAULT '',term_months INTEGER NOT NULL DEFAULT 0,remaining_months INTEGER NOT NULL DEFAULT 0,maturity_date INTEGER NOT NULL DEFAULT 0)");
  createTransferTables(db);
 }
 private void createTransferTables(SQLiteDatabase db){
  db.execSQL("CREATE TABLE IF NOT EXISTS own_transfer_sync (id INTEGER PRIMARY KEY AUTOINCREMENT,source_entry_key TEXT UNIQUE NOT NULL,source_bank TEXT NOT NULL,target_bank TEXT NOT NULL,amount INTEGER NOT NULL,time INTEGER NOT NULL,matched INTEGER NOT NULL DEFAULT 0)");
  db.execSQL("CREATE INDEX IF NOT EXISTS own_transfer_sync_match ON own_transfer_sync(source_bank,target_bank,amount,time,matched)");
 }
 public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion){
  if(oldVersion<2){
   try{db.execSQL("ALTER TABLE entries ADD COLUMN balance_after INTEGER");}catch(SQLiteException ignored){}
   try{db.execSQL("ALTER TABLE entries ADD COLUMN processed_time INTEGER NOT NULL DEFAULT 0");}catch(SQLiteException ignored){}
   try{db.execSQL("ALTER TABLE entries ADD COLUMN auth_code TEXT NOT NULL DEFAULT ''");}catch(SQLiteException ignored){}
   try{db.execSQL("ALTER TABLE entries ADD COLUMN counterparty TEXT NOT NULL DEFAULT ''");}catch(SQLiteException ignored){}
   try{db.execSQL("ALTER TABLE entries ADD COLUMN bank_category TEXT NOT NULL DEFAULT ''");}catch(SQLiteException ignored){}
   createFinancialTables(db);
  }
  if(oldVersion<3)createTransferTables(db);
  if(oldVersion<4){
   try{db.execSQL("ALTER TABLE debts ADD COLUMN principal_debt INTEGER NOT NULL DEFAULT 0");}catch(SQLiteException ignored){}
   try{db.execSQL("ALTER TABLE debts ADD COLUMN interest_debt INTEGER NOT NULL DEFAULT 0");}catch(SQLiteException ignored){}
   try{db.execSQL("ALTER TABLE debts ADD COLUMN payment_principal INTEGER NOT NULL DEFAULT 0");}catch(SQLiteException ignored){}
   try{db.execSQL("ALTER TABLE debts ADD COLUMN payment_interest INTEGER NOT NULL DEFAULT 0");}catch(SQLiteException ignored){}
   try{db.execSQL("ALTER TABLE debts ADD COLUMN repayment_accounts TEXT NOT NULL DEFAULT ''");}catch(SQLiteException ignored){}
  }
  if(oldVersion<5){
   try{db.execSQL("ALTER TABLE debts ADD COLUMN term_months INTEGER NOT NULL DEFAULT 0");}catch(SQLiteException ignored){}
   try{db.execSQL("ALTER TABLE debts ADD COLUMN remaining_months INTEGER NOT NULL DEFAULT 0");}catch(SQLiteException ignored){}
   try{db.execSQL("ALTER TABLE debts ADD COLUMN maturity_date INTEGER NOT NULL DEFAULT 0");}catch(SQLiteException ignored){}
  }
 }
 ContentValues values(Entry e){ContentValues v=new ContentValues();v.put("fingerprint",e.key);v.put("time",e.time);v.put("amount",e.amount);v.put("bank",e.bank);v.put("card",e.card);v.put("merchant",e.merchant);v.put("category",e.category);v.put("kind",e.type);v.put("raw",e.raw);v.put("source",e.source);v.put("review",e.review?1:0);if(e.balanceAfter==Long.MIN_VALUE)v.putNull("balance_after");else v.put("balance_after",e.balanceAfter);v.put("processed_time",e.processedTime);v.put("auth_code",e.authCode);v.put("counterparty",e.counterparty);v.put("bank_category",e.bankCategory);return v;}

 public synchronized boolean add(Entry e){SQLiteDatabase db=getWritableDatabase();try(Cursor c=db.rawQuery("SELECT 1 FROM deleted WHERE fingerprint=?",new String[]{e.key})){if(c.moveToFirst())return false;}
  try(Cursor c=db.rawQuery("SELECT category FROM rules WHERE bank=? AND merchant=?",new String[]{e.bank,e.merchant})){if(c.moveToFirst()&&e.type.equals("expense")){e.category=c.getString(0);e.review=false;}}
  if(e.source.equals("bank_push"))try(Cursor c=db.rawQuery("SELECT id,kind FROM entries WHERE fingerprint=?",new String[]{e.key})){
   if(c.moveToFirst()){
    if(c.getString(1).equals("unknown")&&e.counted()){e.id=c.getLong(0);db.update("entries",values(e),"id=?",new String[]{Long.toString(e.id)});applyLiveBalance(db,e);revision++;return true;}
    return false;
   }
  }
  try(Cursor c=db.rawQuery("SELECT 1 FROM entries WHERE bank=? AND raw=? AND raw<>'' AND ABS(time-?)<120000 AND fingerprint<>?",new String[]{e.bank,e.raw,Long.toString(e.time),e.key})){if(c.moveToFirst())e.review=true;}
  if(e.counted()&&!e.card.isEmpty()&&!e.source.equals("manual")&&!e.source.equals("statement")){
   String where="bank=? AND card=? AND amount=? AND kind=? AND ABS(time-?)<120000 AND source<>? AND source<>'manual' AND fingerprint<>?";
   String[] args={e.bank,e.card,Long.toString(e.amount),e.type,Long.toString(e.time),e.source,e.key};
   try(Cursor c=db.rawQuery("SELECT id FROM entries WHERE "+where,args)){if(c.moveToFirst()){e.review=true;ContentValues review=new ContentValues();review.put("review",1);db.update("entries",review,where,args);revision++;}}
  }
  long id=db.insertWithOnConflict("entries",null,values(e),SQLiteDatabase.CONFLICT_IGNORE);if(id!=-1){e.id=id;if(!e.source.equals("statement")&&!e.source.equals("backup"))applyLiveBalance(db,e);revision++;}return id!=-1;
 }

 /** Statement import is bulk and automatic: exact/likely existing rows are skipped, valid new rows are inserted. */
 public synchronized int[] importRows(List<StatementParser.Row> rows){
  SQLiteDatabase db=getWritableDatabase();db.beginTransaction();int[] count=new int[3];
  try{List<Entry> prior=all();for(StatementParser.Row row:rows){
   if(!row.selected||row.exact||!row.entry.counted()||!row.warning.isEmpty()){if(row.exact)count[1]++;continue;}
   if(row.possible||StatementParser.possible(row.entry,prior)){count[2]++;continue;}
   if(add(row.entry)){count[0]++;prior.add(row.entry);}else count[1]++;
  }db.setTransactionSuccessful();return count;}finally{db.endTransaction();}
 }
 public synchronized boolean testWrite(Entry e){SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{Entry copy=new Entry();copy.key="test-"+UUID.randomUUID();copy.time=e.time;copy.amount=e.amount;copy.bank=e.bank;copy.card=e.card;copy.merchant=e.merchant;copy.category=e.category;copy.type=e.type;copy.raw=e.raw;copy.source="test";copy.review=e.review;copy.balanceAfter=e.balanceAfter;copy.counterparty=e.counterparty;long id=db.insert("entries",null,values(copy));if(id<0)return false;copy.id=id;applyLiveBalance(db,copy);return true;}finally{db.endTransaction();}}
 public synchronized void update(Entry e,boolean remember){SQLiteDatabase db=getWritableDatabase();db.update("entries",values(e),"id=?",new String[]{Long.toString(e.id)});if(remember&&e.type.equals("expense")&&!e.merchant.isEmpty()){ContentValues v=new ContentValues();v.put("bank",e.bank);v.put("merchant",e.merchant);v.put("category",e.category);db.insertWithOnConflict("rules",null,v,SQLiteDatabase.CONFLICT_REPLACE);ContentValues cv=new ContentValues();cv.put("category",e.category);db.update("entries",cv,"bank=? AND merchant=? AND kind='expense'",new String[]{e.bank,e.merchant});}revision++;}
 public synchronized void delete(Entry e){SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{ContentValues v=new ContentValues();v.put("fingerprint",e.key);db.insertWithOnConflict("deleted",null,v,SQLiteDatabase.CONFLICT_IGNORE);db.delete("entries","id=?",new String[]{Long.toString(e.id)});db.setTransactionSuccessful();}finally{db.endTransaction();}revision++;}
 static String str(Cursor c,String n){int i=c.getColumnIndex(n);return i<0?"":c.getString(i);}
 public synchronized List<Entry> all(){List<Entry> out=new ArrayList<>();try(Cursor c=getReadableDatabase().query("entries",null,null,null,null,null,"time DESC,id DESC")){while(c.moveToNext()){Entry e=new Entry();e.id=c.getLong(c.getColumnIndexOrThrow("id"));e.key=str(c,"fingerprint");e.time=c.getLong(c.getColumnIndexOrThrow("time"));e.amount=c.getLong(c.getColumnIndexOrThrow("amount"));e.bank=str(c,"bank");e.card=str(c,"card");e.merchant=str(c,"merchant");e.category=str(c,"category");e.type=str(c,"kind");e.raw=str(c,"raw");e.source=str(c,"source");e.review=c.getInt(c.getColumnIndexOrThrow("review"))!=0;int ba=c.getColumnIndex("balance_after");if(ba>=0&&!c.isNull(ba))e.balanceAfter=c.getLong(ba);int pt=c.getColumnIndex("processed_time");if(pt>=0)e.processedTime=c.getLong(pt);e.authCode=str(c,"auth_code");e.counterparty=str(c,"counterparty");e.bankCategory=str(c,"bank_category");out.add(e);}}return out;}

 private static final long OWN_TRANSFER_WINDOW=2L*60*60*1000;
 private void applyLiveBalance(SQLiteDatabase db,Entry e){
  if(!e.counted())return;
  boolean shadowMatched=(e.type.equals("own_in")||e.type.equals("own_out"))&&consumeOwnTransferShadow(db,e);
  if(!shadowMatched)applyCreditDebt(db,e);
  Account a=findLiveDebitAccount(db,e.bank,e.card);
  if(a==null&&e.balanceAfter!=Long.MIN_VALUE&&!e.bank.equals("Альфа-Банк")){
   a=new Account();a.bank=e.bank;a.card=e.bank.equals("Т-Банк")?"":e.card;a.name=e.bank+(a.card.isEmpty()?"":" •• "+a.card);a.kind="debit";a.balance=e.balanceAfter;a.hasBalance=true;a.updatedAt=System.currentTimeMillis();a.source="live";
   ContentValues nv=new ContentValues();nv.put("bank",a.bank);nv.put("card",a.card);nv.put("name",a.name);nv.put("kind",a.kind);nv.put("balance",a.balance);nv.put("has_balance",1);nv.put("credit_limit",0);nv.put("debt",0);nv.put("updated_at",a.updatedAt);nv.put("source",a.source);db.insertWithOnConflict("accounts",null,nv,SQLiteDatabase.CONFLICT_REPLACE);
  }else if(a!=null){
   ContentValues v=new ContentValues();boolean changed=false;
   if(e.balanceAfter!=Long.MIN_VALUE&&a.kind.equals("debit")){v.put("balance",e.balanceAfter);v.put("has_balance",1);changed=true;}
   else if(!shadowMatched&&a.hasBalance&&a.kind.equals("debit")&&e.direction()!=0){v.put("balance",Math.max(0,a.balance+e.direction()*e.amount));changed=true;}
   if(changed){v.put("updated_at",System.currentTimeMillis());v.put("source","live");db.update("accounts",v,"id=?",new String[]{Long.toString(a.id)});}
  }
  if(!shadowMatched&&e.type.equals("cash")&&!e.bank.equals("Наличные"))applyCashIncrease(db,e.amount);
  if(!shadowMatched&&e.type.equals("cash")&&!e.bank.equals("Наличные"))adjustDebitAccount(db,"Наличные",e.amount,"cash-withdrawal");
  if(!shadowMatched&&e.type.equals("own_out")&&!e.counterparty.isEmpty()&&!hasMatchingOwnIncoming(db,e)){
   if(applyCounterpartyCredit(db,e.counterparty,e.amount)||applyCounterpartyDebit(db,e.counterparty,e.amount))recordOwnTransferShadow(db,e.bank,e.counterparty,e);
  }
  if(!shadowMatched&&e.type.equals("own_in")&&!e.counterparty.isEmpty()&&!hasMatchingOwnOutgoing(db,e)){
   if(applySourceDebit(db,e.counterparty,e.amount))recordOwnTransferShadow(db,e.counterparty,e.bank,e);
  }
  cleanupTransferShadows(db,e.time);
 }

 private Account findLiveDebitAccount(SQLiteDatabase db,String bank,String card){
  String c=card==null?"":card;
  if(bank.equals("Т-Банк")){
   try(Cursor x=db.rawQuery("SELECT * FROM accounts WHERE bank=? AND kind='debit' ORDER BY CASE WHEN card='' THEN 0 WHEN card=? THEN 1 ELSE 2 END,id",new String[]{bank,c})){if(x.moveToFirst())return account(x);}
  }
  Account a=findAccount(db,bank,c);return a!=null&&a.kind.equals("debit")?a:null;
 }
 private void applyCreditDebt(SQLiteDatabase db,Entry e){
  if(e.direction()==0)return;
  try(Cursor c=db.rawQuery("SELECT id,debt FROM debts WHERE bank=? AND kind='credit_card' ORDER BY id LIMIT 1",new String[]{e.bank})){
   if(!c.moveToFirst())return;long id=c.getLong(0),current=c.getLong(1);long next=e.direction()<0?current+e.amount:Math.max(0,current-e.amount);ContentValues v=new ContentValues();v.put("debt",next);db.update("debts",v,"id=?",new String[]{Long.toString(id)});
  }
 }
 private void applyCashIncrease(SQLiteDatabase db,long amount){
  Account cash=findLiveDebitAccount(db,"Наличные","");
  if(cash==null){ContentValues v=new ContentValues();v.put("bank","Наличные");v.put("card","");v.put("name","Наличные");v.put("kind","debit");v.put("balance",amount);v.put("has_balance",1);v.put("credit_limit",0);v.put("debt",0);v.put("updated_at",System.currentTimeMillis());v.put("source","cash-withdrawal");db.insertWithOnConflict("accounts",null,v,SQLiteDatabase.CONFLICT_REPLACE);return;}
  if(!cash.hasBalance)return;ContentValues v=new ContentValues();v.put("balance",cash.balance+amount);v.put("updated_at",System.currentTimeMillis());v.put("source","cash-withdrawal");db.update("accounts",v,"id=?",new String[]{Long.toString(cash.id)});
 }
 private boolean applyCounterpartyCredit(SQLiteDatabase db,String bank,long amount){
  try(Cursor c=db.rawQuery("SELECT id,debt FROM debts WHERE bank=? AND kind='credit_card' ORDER BY id LIMIT 1",new String[]{bank})){
   if(!c.moveToFirst())return false;long id=c.getLong(0),current=c.getLong(1);ContentValues v=new ContentValues();v.put("debt",Math.max(0,current-amount));db.update("debts",v,"id=?",new String[]{Long.toString(id)});return true;
  }
 }
 private boolean adjustDebitAccount(SQLiteDatabase db,String bank,long delta,String source){
  Account a=findLiveDebitAccount(db,bank,"");
  if(a==null){ContentValues v=new ContentValues();v.put("bank",bank);v.put("card","");v.put("name",bank);v.put("kind","debit");v.put("balance",Math.max(0,delta));v.put("has_balance",1);v.put("credit_limit",0);v.put("debt",0);v.put("updated_at",System.currentTimeMillis());v.put("source",source);db.insertWithOnConflict("accounts",null,v,SQLiteDatabase.CONFLICT_REPLACE);return true;}
  if(!a.hasBalance)return false;ContentValues v=new ContentValues();v.put("balance",Math.max(0,a.balance+delta));v.put("updated_at",System.currentTimeMillis());v.put("source",source);db.update("accounts",v,"id=?",new String[]{Long.toString(a.id)});return true;
 }
 private boolean applyCounterpartyDebit(SQLiteDatabase db,String bank,long amount){
  return adjustDebitAccount(db,bank,amount,"live-transfer");
 }
 private boolean applySourceDebit(SQLiteDatabase db,String bank,long amount){
  Account source=findLiveDebitAccount(db,bank,"");if(source==null||!source.hasBalance)return false;return adjustDebitAccount(db,bank,-amount,"live-transfer");
 }
 private boolean hasMatchingOwnIncoming(SQLiteDatabase db,Entry out){
  String[] args={out.counterparty,out.bank,Long.toString(out.amount),Long.toString(out.time),Long.toString(OWN_TRANSFER_WINDOW)};
  try(Cursor c=db.rawQuery("SELECT 1 FROM entries WHERE bank=? AND counterparty=? AND kind='own_in' AND amount=? AND ABS(time-?)<=? LIMIT 1",args)){return c.moveToFirst();}
 }
 private boolean hasMatchingOwnOutgoing(SQLiteDatabase db,Entry in){
  String[] args={in.counterparty,in.bank,Long.toString(in.amount),Long.toString(in.time),Long.toString(OWN_TRANSFER_WINDOW)};
  try(Cursor c=db.rawQuery("SELECT 1 FROM entries WHERE bank=? AND counterparty=? AND kind='own_out' AND amount=? AND ABS(time-?)<=? LIMIT 1",args)){return c.moveToFirst();}
 }
 private void recordOwnTransferShadow(SQLiteDatabase db,String sourceBank,String targetBank,Entry e){
  ContentValues v=new ContentValues();v.put("source_entry_key",e.key);v.put("source_bank",sourceBank);v.put("target_bank",targetBank);v.put("amount",e.amount);v.put("time",e.time);v.put("matched",0);db.insertWithOnConflict("own_transfer_sync",null,v,SQLiteDatabase.CONFLICT_IGNORE);
 }
 private boolean consumeOwnTransferShadow(SQLiteDatabase db,Entry e){
  if(e.counterparty.isEmpty())return false;String source=e.type.equals("own_in")?e.counterparty:e.bank,target=e.type.equals("own_in")?e.bank:e.counterparty;String[] args={source,target,Long.toString(e.amount),Long.toString(e.time),Long.toString(OWN_TRANSFER_WINDOW),Long.toString(e.time)};
  try(Cursor c=db.rawQuery("SELECT id FROM own_transfer_sync WHERE source_bank=? AND target_bank=? AND amount=? AND matched=0 AND ABS(time-?)<=? ORDER BY ABS(time-?) LIMIT 1",args)){
   if(!c.moveToFirst())return false;ContentValues v=new ContentValues();v.put("matched",1);db.update("own_transfer_sync",v,"id=?",new String[]{Long.toString(c.getLong(0))});return true;
  }
 }
 private void cleanupTransferShadows(SQLiteDatabase db,long now){db.delete("own_transfer_sync","time<?",new String[]{Long.toString(now-14L*24*60*60*1000)});}
 private Account findAccount(SQLiteDatabase db,String bank,String card){
  Account fallback=null;try(Cursor c=db.rawQuery("SELECT * FROM accounts WHERE bank=? ORDER BY CASE WHEN card=? THEN 0 WHEN card='' THEN 1 ELSE 2 END,id",new String[]{bank,card==null?"":card})){while(c.moveToNext()){Account a=account(c);if(a.card.equals(card==null?"":card)||a.card.isEmpty())return a;if(fallback==null)fallback=a;}}catch(Exception ignored){}
  return fallback;
 }
 private Account account(Cursor c){Account a=new Account();a.id=c.getLong(c.getColumnIndexOrThrow("id"));a.bank=str(c,"bank");a.card=str(c,"card");a.name=str(c,"name");a.kind=str(c,"kind");a.balance=c.getLong(c.getColumnIndexOrThrow("balance"));a.hasBalance=c.getInt(c.getColumnIndexOrThrow("has_balance"))!=0;a.creditLimit=c.getLong(c.getColumnIndexOrThrow("credit_limit"));a.debt=c.getLong(c.getColumnIndexOrThrow("debt"));a.updatedAt=c.getLong(c.getColumnIndexOrThrow("updated_at"));a.source=str(c,"source");return a;}
 public synchronized List<Account> accounts(){List<Account> out=new ArrayList<>();try(Cursor c=getReadableDatabase().query("accounts",null,null,null,null,null,"bank,card")){while(c.moveToNext())out.add(account(c));}return out;}
 public synchronized Account account(String bank,String card){return findAccount(getReadableDatabase(),bank,card==null?"":card);}
 public synchronized void saveAccount(Account a){ContentValues v=new ContentValues();v.put("bank",a.bank);v.put("card",a.card==null?"":a.card);v.put("name",a.name==null?"":a.name);v.put("kind",a.kind==null?"debit":a.kind);v.put("balance",a.balance);v.put("has_balance",a.hasBalance?1:0);v.put("credit_limit",a.creditLimit);v.put("debt",a.debt);v.put("updated_at",System.currentTimeMillis());v.put("source",a.source==null?"manual":a.source);SQLiteDatabase db=getWritableDatabase();db.insertWithOnConflict("accounts",null,v,SQLiteDatabase.CONFLICT_REPLACE);revision++;}
 public synchronized void syncStatementAccount(String bank,String card,long closingBalance,String source){Account a=account(bank,card);if(a==null)a=new Account();a.bank=bank;a.card=card==null?"":card;a.name=bank+(a.card.isEmpty()?"":" •• "+a.card);a.kind=bank.equals("Альфа-Банк")?"credit":"debit";a.balance=closingBalance;a.hasBalance=true;a.source=source==null?"statement":source;saveAccount(a);}
 public synchronized long totalOwnMoney(){long sum=0;for(Account a:accounts())if(a.kind.equals("debit")&&a.hasBalance)sum+=a.balance;return sum;}

 private Debt debt(Cursor c){Debt d=new Debt();d.id=c.getLong(c.getColumnIndexOrThrow("id"));d.bank=str(c,"bank");d.name=str(c,"name");d.kind=str(c,"kind");d.limitOrPrincipal=c.getLong(c.getColumnIndexOrThrow("limit_or_principal"));d.debt=c.getLong(c.getColumnIndexOrThrow("debt"));d.monthlyPayment=c.getLong(c.getColumnIndexOrThrow("monthly_payment"));d.rateBps=c.getInt(c.getColumnIndexOrThrow("rate_bps"));d.nextPayment=c.getLong(c.getColumnIndexOrThrow("next_payment"));int i=c.getColumnIndex("principal_debt");if(i>=0)d.principalDebt=c.getLong(i);i=c.getColumnIndex("interest_debt");if(i>=0)d.interestDebt=c.getLong(i);i=c.getColumnIndex("payment_principal");if(i>=0)d.paymentPrincipal=c.getLong(i);i=c.getColumnIndex("payment_interest");if(i>=0)d.paymentInterest=c.getLong(i);d.repaymentAccounts=str(c,"repayment_accounts");i=c.getColumnIndex("term_months");if(i>=0)d.termMonths=c.getInt(i);i=c.getColumnIndex("remaining_months");if(i>=0)d.remainingMonths=c.getInt(i);i=c.getColumnIndex("maturity_date");if(i>=0)d.maturityDate=c.getLong(i);return d;}
 public synchronized List<Debt> debts(){List<Debt> out=new ArrayList<>();try(Cursor c=getReadableDatabase().query("debts",null,null,null,null,null,"bank,name")){while(c.moveToNext())out.add(debt(c));}return out;}
 public synchronized void saveDebt(Debt d){ContentValues v=new ContentValues();v.put("bank",d.bank);v.put("name",d.name);v.put("kind",d.kind);v.put("limit_or_principal",d.limitOrPrincipal);v.put("debt",d.debt);v.put("monthly_payment",d.monthlyPayment);v.put("rate_bps",d.rateBps);v.put("next_payment",d.nextPayment);v.put("principal_debt",d.principalDebt);v.put("interest_debt",d.interestDebt);v.put("payment_principal",d.paymentPrincipal);v.put("payment_interest",d.paymentInterest);v.put("repayment_accounts",d.repaymentAccounts==null?"":d.repaymentAccounts);v.put("term_months",d.termMonths);v.put("remaining_months",d.remainingMonths);v.put("maturity_date",d.maturityDate);SQLiteDatabase db=getWritableDatabase();if(d.id>0)db.update("debts",v,"id=?",new String[]{Long.toString(d.id)});else d.id=db.insert("debts",null,v);revision++;}
 public synchronized Debt syncCreditStatement(String bank,String card,long limit,long debt){
  Debt d=null;try(Cursor c=getReadableDatabase().rawQuery("SELECT * FROM debts WHERE bank=? AND kind='credit_card' ORDER BY id LIMIT 1",new String[]{bank})){if(c.moveToFirst())d=debt(c);}
  if(d==null)d=new Debt();d.bank=bank;d.kind="credit_card";d.name=bank+(card==null||card.isEmpty()?" кредитная карта":" •• "+card);if(limit>0)d.limitOrPrincipal=limit;d.debt=Math.max(0,debt);saveDebt(d);return d;
 }
 public synchronized void deleteDebt(long id){getWritableDatabase().delete("debts","id=?",new String[]{Long.toString(id)});revision++;}

 public synchronized void clear(){SQLiteDatabase db=getWritableDatabase();db.beginTransaction();try{db.delete("entries",null,null);db.delete("deleted",null,null);db.delete("rules",null,null);db.delete("accounts",null,null);db.delete("debts",null,null);db.delete("own_transfer_sync",null,null);db.setTransactionSuccessful();}finally{db.endTransaction();}revision++;}
}
